<?php
namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ChampsformulaireTable extends AbstractTableGateway
{
    protected $table ='champsformulaire';
    protected $tableName ='champsformulaire';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Champsformulaire);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('champsformulaire')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
    			$id=$row->idchampsformulaire;
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
    	'idchampsformulaire' => null
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
    public function getChampsformulaire($id)
    {
        $id  = (int) $id;
        $rowset = $this->select(array('idchampsformulaire' => $id));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchChampsformulaire($idgroupeformulaire, $labelchamps, $helpchamps, $datecreation, $datesuspond, $iconeprop, $ordrechamps)
    {
        $select = $this->getSelect();
                if ($idgroupeformulaire != null) {
        	$select->where->like('idgroupeformulaire' ,'%'.$idgroupeformulaire.'%');
        }
                if ($labelchamps != null) {
        	$select->where->like('labelchamps' ,'%'.$labelchamps.'%');
        }
                if ($helpchamps != null) {
        	$select->where->like('helpchamps' ,'%'.$helpchamps.'%');
        }
                if ($datecreation != null) {
        	$select->where->like('datecreation' ,'%'.$datecreation.'%');
        }
                if ($datesuspond != null) {
        	$select->where->like('datesuspond' ,'%'.$datesuspond.'%');
        }
                if ($iconeprop != null) {
        	$select->where->like('iconeprop' ,'%'.$iconeprop.'%');
        }
                if ($ordrechamps != null) {
        	$select->where->like('ordrechamps' ,'%'.$ordrechamps.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveChampsformulaire(Champsformulaire $champsformulaire)
    {
        $data = array(
        	            'idgroupeformulaire' => $champsformulaire->idgroupeformulaire,
                        'labelchamps' => $champsformulaire->labelchamps,
                        'helpchamps' => $champsformulaire->helpchamps,
                        'datecreation' => $champsformulaire->datecreation,
                        'datesuspond' => $champsformulaire->datesuspond,
                        'iconeprop' => $champsformulaire->iconeprop,
                        'ordrechamps' => $champsformulaire->ordrechamps,
                    );

        $id = (int)$champsformulaire->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
            if ($this->getChampsformulaire($id)) {
                $this->update($data, array('idchampsformulaire' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
        }
    }

    public function addChampsformulaire($idgroupeformulaire, $labelchamps = null, $helpchamps = null, $datecreation = null, $datesuspond = null, $iconeprop = null, $ordrechamps = null)
    {
        $data = array(            'idgroupeformulaire' => $idgroupeformulaire,
                    );
                if ($labelchamps != null) {
        	$data['labelchamps'] = $labelchamps;
        }
                if ($helpchamps != null) {
        	$data['helpchamps'] = $helpchamps;
        }
                if ($datecreation != null) {
        	$data['datecreation'] = $datecreation;
        }
                if ($datesuspond != null) {
        	$data['datesuspond'] = $datesuspond;
        }
                if ($iconeprop != null) {
        	$data['iconeprop'] = $iconeprop;
        }
                if ($ordrechamps != null) {
        	$data['ordrechamps'] = $ordrechamps;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   
    public function updateChampsformulaire($idchampsformulaire, $idgroupeformulaire, $labelchamps, $helpchamps, $datecreation, $datesuspond, $iconeprop, $ordrechamps)
    {
        $data = array(
        	            'idgroupeformulaire' => $champsformulaire->idgroupeformulaire,
                        'labelchamps' => $champsformulaire->labelchamps,
                        'helpchamps' => $champsformulaire->helpchamps,
                        'datecreation' => $champsformulaire->datecreation,
                        'datesuspond' => $champsformulaire->datesuspond,
                        'iconeprop' => $champsformulaire->iconeprop,
                        'ordrechamps' => $champsformulaire->ordrechamps,
                            );
        $this->update($data, array(idchampsformulaire => $id));
    }

    public function deleteChampsformulaire($id)
    {
        $this->delete(array('idchampsformulaire' => $id));
    }

}
