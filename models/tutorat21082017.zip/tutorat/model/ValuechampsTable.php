<?php
namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ValuechampsTable extends AbstractTableGateway
{
    protected $table ='valuechamps';
    protected $tableName ='valuechamps';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Valuechamps);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('valuechamps')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
    			$id=$row->array('idgroupeformulaire', 'idchampsformulaire');
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
    	'array('idgroupeformulaire', 'idchampsformulaire')' => null
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
    public function getValuechamps($id)
    {
        $id  = (int) $id;
        $rowset = $this->select(array('array('idgroupeformulaire', 'idchampsformulaire')' => $id));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchValuechamps($idgroupeformulaire, $idchampsformulaire, $labelchampsprop, $valeuchoisi, $descvaluechoix, $notevaluechoix, $valuechoisidate, $valuechoisiint, $idtablechoisi, $dyntable)
    {
        $select = $this->getSelect();
                if ($idgroupeformulaire != null) {
        	$select->where->like('idgroupeformulaire' ,'%'.$idgroupeformulaire.'%');
        }
                if ($idchampsformulaire != null) {
        	$select->where->like('idchampsformulaire' ,'%'.$idchampsformulaire.'%');
        }
                if ($labelchampsprop != null) {
        	$select->where->like('labelchampsprop' ,'%'.$labelchampsprop.'%');
        }
                if ($valeuchoisi != null) {
        	$select->where->like('valeuchoisi' ,'%'.$valeuchoisi.'%');
        }
                if ($descvaluechoix != null) {
        	$select->where->like('descvaluechoix' ,'%'.$descvaluechoix.'%');
        }
                if ($notevaluechoix != null) {
        	$select->where->like('notevaluechoix' ,'%'.$notevaluechoix.'%');
        }
                if ($valuechoisidate != null) {
        	$select->where->like('valuechoisidate' ,'%'.$valuechoisidate.'%');
        }
                if ($valuechoisiint != null) {
        	$select->where->like('valuechoisiint' ,'%'.$valuechoisiint.'%');
        }
                if ($idtablechoisi != null) {
        	$select->where->like('idtablechoisi' ,'%'.$idtablechoisi.'%');
        }
                if ($dyntable != null) {
        	$select->where->like('dyntable' ,'%'.$dyntable.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveValuechamps(Valuechamps $valuechamps)
    {
        $data = array(
        	            'idgroupeformulaire' => $valuechamps->idgroupeformulaire,
                        'idchampsformulaire' => $valuechamps->idchampsformulaire,
                        'labelchampsprop' => $valuechamps->labelchampsprop,
                        'valeuchoisi' => $valuechamps->valeuchoisi,
                        'descvaluechoix' => $valuechamps->descvaluechoix,
                        'notevaluechoix' => $valuechamps->notevaluechoix,
                        'valuechoisidate' => $valuechamps->valuechoisidate,
                        'valuechoisiint' => $valuechamps->valuechoisiint,
                        'idtablechoisi' => $valuechamps->idtablechoisi,
                        'dyntable' => $valuechamps->dyntable,
                    );

        $id = (int)$valuechamps->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
            if ($this->getValuechamps($id)) {
                $this->update($data, array('array('idgroupeformulaire', 'idchampsformulaire')' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
        }
    }

    public function addValuechamps($idgroupeformulaire, $idchampsformulaire, $labelchampsprop = null, $valeuchoisi = null, $descvaluechoix = null, $notevaluechoix = null, $valuechoisidate = null, $valuechoisiint = null, $idtablechoisi = null, $dyntable = null)
    {
        $data = array(            'idgroupeformulaire' => $idgroupeformulaire,
                        'idchampsformulaire' => $idchampsformulaire,
                    );
                if ($labelchampsprop != null) {
        	$data['labelchampsprop'] = $labelchampsprop;
        }
                if ($valeuchoisi != null) {
        	$data['valeuchoisi'] = $valeuchoisi;
        }
                if ($descvaluechoix != null) {
        	$data['descvaluechoix'] = $descvaluechoix;
        }
                if ($notevaluechoix != null) {
        	$data['notevaluechoix'] = $notevaluechoix;
        }
                if ($valuechoisidate != null) {
        	$data['valuechoisidate'] = $valuechoisidate;
        }
                if ($valuechoisiint != null) {
        	$data['valuechoisiint'] = $valuechoisiint;
        }
                if ($idtablechoisi != null) {
        	$data['idtablechoisi'] = $idtablechoisi;
        }
                if ($dyntable != null) {
        	$data['dyntable'] = $dyntable;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   
    public function updateValuechamps($array('idgroupeformulaire', 'idchampsformulaire'), $idgroupeformulaire, $idchampsformulaire, $labelchampsprop, $valeuchoisi, $descvaluechoix, $notevaluechoix, $valuechoisidate, $valuechoisiint, $idtablechoisi, $dyntable)
    {
        $data = array(
        	            'idgroupeformulaire' => $valuechamps->idgroupeformulaire,
                        'idchampsformulaire' => $valuechamps->idchampsformulaire,
                        'labelchampsprop' => $valuechamps->labelchampsprop,
                        'valeuchoisi' => $valuechamps->valeuchoisi,
                        'descvaluechoix' => $valuechamps->descvaluechoix,
                        'notevaluechoix' => $valuechamps->notevaluechoix,
                        'valuechoisidate' => $valuechamps->valuechoisidate,
                        'valuechoisiint' => $valuechamps->valuechoisiint,
                        'idtablechoisi' => $valuechamps->idtablechoisi,
                        'dyntable' => $valuechamps->dyntable,
                            );
        $this->update($data, array(array('idgroupeformulaire', 'idchampsformulaire') => $id));
    }

    public function deleteValuechamps($id)
    {
        $this->delete(array('array('idgroupeformulaire', 'idchampsformulaire')' => $id));
    }

}
