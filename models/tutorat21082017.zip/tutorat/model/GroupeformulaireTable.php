<?php
namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class GroupeformulaireTable extends AbstractTableGateway
{
    protected $table ='groupeformulaire';
    protected $tableName ='groupeformulaire';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Groupeformulaire);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('groupeformulaire')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
    			$id=$row->idgroupeformulaire;
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
    	'idgroupeformulaire' => null
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
    public function getGroupeformulaire($id)
    {
        $id  = (int) $id;
        $rowset = $this->select(array('idgroupeformulaire' => $id));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchGroupeformulaire($idperegroupeformulaire, $idtypegroupeformulaire, $idtableactor, $labelgroupe, $helpgroupeform, $icone, $ordregroupeform, $suspondre)
    {
        $select = $this->getSelect();
                if ($idperegroupeformulaire != null) {
        	$select->where->like('idperegroupeformulaire' ,'%'.$idperegroupeformulaire.'%');
        }
                if ($idtypegroupeformulaire != null) {
        	$select->where->like('idtypegroupeformulaire' ,'%'.$idtypegroupeformulaire.'%');
        }
                if ($idtableactor != null) {
        	$select->where->like('idtableactor' ,'%'.$idtableactor.'%');
        }
                if ($labelgroupe != null) {
        	$select->where->like('labelgroupe' ,'%'.$labelgroupe.'%');
        }
                if ($helpgroupeform != null) {
        	$select->where->like('helpgroupeform' ,'%'.$helpgroupeform.'%');
        }
                if ($icone != null) {
        	$select->where->like('icone' ,'%'.$icone.'%');
        }
                if ($ordregroupeform != null) {
        	$select->where->like('ordregroupeform' ,'%'.$ordregroupeform.'%');
        }
                if ($suspondre != null) {
        	$select->where->like('suspondre' ,'%'.$suspondre.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveGroupeformulaire(Groupeformulaire $groupeformulaire)
    {
        $data = array(
        	            'idperegroupeformulaire' => $groupeformulaire->idperegroupeformulaire,
                        'idtypegroupeformulaire' => $groupeformulaire->idtypegroupeformulaire,
                        'idtableactor' => $groupeformulaire->idtableactor,
                        'labelgroupe' => $groupeformulaire->labelgroupe,
                        'helpgroupeform' => $groupeformulaire->helpgroupeform,
                        'icone' => $groupeformulaire->icone,
                        'ordregroupeform' => $groupeformulaire->ordregroupeform,
                        'suspondre' => $groupeformulaire->suspondre,
                    );

        $id = (int)$groupeformulaire->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
            if ($this->getGroupeformulaire($id)) {
                $this->update($data, array('idgroupeformulaire' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
        }
    }

    public function addGroupeformulaire($idtypegroupeformulaire, $idtableactor, $idperegroupeformulaire = null, $labelgroupe = null, $helpgroupeform = null, $icone = null, $ordregroupeform = null, $suspondre = null)
    {
        $data = array(            'idtypegroupeformulaire' => $idtypegroupeformulaire,
                        'idtableactor' => $idtableactor,
                    );
                if ($idperegroupeformulaire != null) {
        	$data['idperegroupeformulaire'] = $idperegroupeformulaire;
        }
                if ($labelgroupe != null) {
        	$data['labelgroupe'] = $labelgroupe;
        }
                if ($helpgroupeform != null) {
        	$data['helpgroupeform'] = $helpgroupeform;
        }
                if ($icone != null) {
        	$data['icone'] = $icone;
        }
                if ($ordregroupeform != null) {
        	$data['ordregroupeform'] = $ordregroupeform;
        }
                if ($suspondre != null) {
        	$data['suspondre'] = $suspondre;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   
    public function updateGroupeformulaire($idgroupeformulaire, $idperegroupeformulaire, $idtypegroupeformulaire, $idtableactor, $labelgroupe, $helpgroupeform, $icone, $ordregroupeform, $suspondre)
    {
        $data = array(
        	            'idperegroupeformulaire' => $groupeformulaire->idperegroupeformulaire,
                        'idtypegroupeformulaire' => $groupeformulaire->idtypegroupeformulaire,
                        'idtableactor' => $groupeformulaire->idtableactor,
                        'labelgroupe' => $groupeformulaire->labelgroupe,
                        'helpgroupeform' => $groupeformulaire->helpgroupeform,
                        'icone' => $groupeformulaire->icone,
                        'ordregroupeform' => $groupeformulaire->ordregroupeform,
                        'suspondre' => $groupeformulaire->suspondre,
                            );
        $this->update($data, array(idgroupeformulaire => $id));
    }

    public function deleteGroupeformulaire($id)
    {
        $this->delete(array('idgroupeformulaire' => $id));
    }

}
