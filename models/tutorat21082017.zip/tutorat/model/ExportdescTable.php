<?php
namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ExportdescTable extends AbstractTableGateway
{
    protected $table ='exportdesc';
    protected $tableName ='exportdesc';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Exportdesc);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('exportdesc')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
    			$id=$row->idexportdesc;
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
    	'idexportdesc' => null
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
    public function getExportdesc($id)
    {
        $id  = (int) $id;
        $rowset = $this->select(array('idexportdesc' => $id));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchExportdesc($idtypegroupeformulaire, $idexportmodel, $idpereexportdesc, $requestexport)
    {
        $select = $this->getSelect();
                if ($idtypegroupeformulaire != null) {
        	$select->where->like('idtypegroupeformulaire' ,'%'.$idtypegroupeformulaire.'%');
        }
                if ($idexportmodel != null) {
        	$select->where->like('idexportmodel' ,'%'.$idexportmodel.'%');
        }
                if ($idpereexportdesc != null) {
        	$select->where->like('idpereexportdesc' ,'%'.$idpereexportdesc.'%');
        }
                if ($requestexport != null) {
        	$select->where->like('requestexport' ,'%'.$requestexport.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveExportdesc(Exportdesc $exportdesc)
    {
        $data = array(
        	            'idtypegroupeformulaire' => $exportdesc->idtypegroupeformulaire,
                        'idexportmodel' => $exportdesc->idexportmodel,
                        'idpereexportdesc' => $exportdesc->idpereexportdesc,
                        'requestexport' => $exportdesc->requestexport,
                    );

        $id = (int)$exportdesc->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
            if ($this->getExportdesc($id)) {
                $this->update($data, array('idexportdesc' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
        }
    }

    public function addExportdesc($idtypegroupeformulaire, $idexportmodel, $idpereexportdesc = null, $requestexport = null)
    {
        $data = array(            'idtypegroupeformulaire' => $idtypegroupeformulaire,
                        'idexportmodel' => $idexportmodel,
                    );
                if ($idpereexportdesc != null) {
        	$data['idpereexportdesc'] = $idpereexportdesc;
        }
                if ($requestexport != null) {
        	$data['requestexport'] = $requestexport;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   
    public function updateExportdesc($idexportdesc, $idtypegroupeformulaire, $idexportmodel, $idpereexportdesc, $requestexport)
    {
        $data = array(
        	            'idtypegroupeformulaire' => $exportdesc->idtypegroupeformulaire,
                        'idexportmodel' => $exportdesc->idexportmodel,
                        'idpereexportdesc' => $exportdesc->idpereexportdesc,
                        'requestexport' => $exportdesc->requestexport,
                            );
        $this->update($data, array(idexportdesc => $id));
    }

    public function deleteExportdesc($id)
    {
        $this->delete(array('idexportdesc' => $id));
    }

}
