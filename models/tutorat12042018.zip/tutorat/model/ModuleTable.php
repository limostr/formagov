<?php
 
//		$id=$row->idModule;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ModuleTable extends AbstractTableGateway
{
    protected $table ='module';
    protected $tableName ='module';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Module);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('module')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idModule;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idModule' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getModule($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idModule' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchModule($idue, $idTypemodule, $idniveauformation, $idperiode, $idRegime, $idNature, $coefficient, $credit, $Nombredesemaine, $codeue, $titremodule, $noteeleminatoire, $descriptionecue, $nbrscience, $nbroption, $resumer, $codemes, $codemoodle)
    {
        $select = $this->getSelect();
                if ($idue != null) {
        	$select->where->like('idue' ,'%'.$idue.'%');
        }
                if ($idTypemodule != null) {
        	$select->where->like('idTypemodule' ,'%'.$idTypemodule.'%');
        }
                if ($idniveauformation != null) {
        	$select->where->like('idniveauformation' ,'%'.$idniveauformation.'%');
        }
                if ($idperiode != null) {
        	$select->where->like('idperiode' ,'%'.$idperiode.'%');
        }
                if ($idRegime != null) {
        	$select->where->like('idRegime' ,'%'.$idRegime.'%');
        }
                if ($idNature != null) {
        	$select->where->like('idNature' ,'%'.$idNature.'%');
        }
                if ($coefficient != null) {
        	$select->where->like('coefficient' ,'%'.$coefficient.'%');
        }
                if ($credit != null) {
        	$select->where->like('credit' ,'%'.$credit.'%');
        }
                if ($Nombredesemaine != null) {
        	$select->where->like('Nombredesemaine' ,'%'.$Nombredesemaine.'%');
        }
                if ($codeue != null) {
        	$select->where->like('codeue' ,'%'.$codeue.'%');
        }
                if ($titremodule != null) {
        	$select->where->like('titremodule' ,'%'.$titremodule.'%');
        }
                if ($noteeleminatoire != null) {
        	$select->where->like('noteeleminatoire' ,'%'.$noteeleminatoire.'%');
        }
                if ($descriptionecue != null) {
        	$select->where->like('descriptionecue' ,'%'.$descriptionecue.'%');
        }
                if ($nbrscience != null) {
        	$select->where->like('nbrscience' ,'%'.$nbrscience.'%');
        }
                if ($nbroption != null) {
        	$select->where->like('nbroption' ,'%'.$nbroption.'%');
        }
                if ($resumer != null) {
        	$select->where->like('resumer' ,'%'.$resumer.'%');
        }
                if ($codemes != null) {
        	$select->where->like('codemes' ,'%'.$codemes.'%');
        }
                if ($codemoodle != null) {
        	$select->where->like('codemoodle' ,'%'.$codemoodle.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveModule(Module $module)
    {
        $data = array(
        	            'idue' => $module->idue,
                        'idTypemodule' => $module->idTypemodule,
                        'idniveauformation' => $module->idniveauformation,
                        'idperiode' => $module->idperiode,
                        'idRegime' => $module->idRegime,
                        'idNature' => $module->idNature,
                        'coefficient' => $module->coefficient,
                        'credit' => $module->credit,
                        'Nombredesemaine' => $module->Nombredesemaine,
                        'codeue' => $module->codeue,
                        'titremodule' => $module->titremodule,
                        'noteeleminatoire' => $module->noteeleminatoire,
                        'descriptionecue' => $module->descriptionecue,
                        'nbrscience' => $module->nbrscience,
                        'nbroption' => $module->nbroption,
                        'resumer' => $module->resumer,
                        'codemes' => $module->codemes,
                        'codemoodle' => $module->codemoodle,
                    );

        $id = (int)$module->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getModule($id)) {
                $this->update($data, array('idModule' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addModule($idTypemodule, $idniveauformation, $idperiode, $idRegime, $idNature, $idue = null, $coefficient = null, $credit = null, $Nombredesemaine = null, $codeue = null, $titremodule = null, $noteeleminatoire = null, $descriptionecue = null, $nbrscience = null, $nbroption = null, $resumer = null, $codemes = null, $codemoodle = null)
    {
        $data = array(            'idTypemodule' => $idTypemodule,
                        'idniveauformation' => $idniveauformation,
                        'idperiode' => $idperiode,
                        'idRegime' => $idRegime,
                        'idNature' => $idNature,
                    );
                if ($idue != null) {
        	$data['idue'] = $idue;
        }
                if ($coefficient != null) {
        	$data['coefficient'] = $coefficient;
        }
                if ($credit != null) {
        	$data['credit'] = $credit;
        }
                if ($Nombredesemaine != null) {
        	$data['Nombredesemaine'] = $Nombredesemaine;
        }
                if ($codeue != null) {
        	$data['codeue'] = $codeue;
        }
                if ($titremodule != null) {
        	$data['titremodule'] = $titremodule;
        }
                if ($noteeleminatoire != null) {
        	$data['noteeleminatoire'] = $noteeleminatoire;
        }
                if ($descriptionecue != null) {
        	$data['descriptionecue'] = $descriptionecue;
        }
                if ($nbrscience != null) {
        	$data['nbrscience'] = $nbrscience;
        }
                if ($nbroption != null) {
        	$data['nbroption'] = $nbroption;
        }
                if ($resumer != null) {
        	$data['resumer'] = $resumer;
        }
                if ($codemes != null) {
        	$data['codemes'] = $codemes;
        }
                if ($codemoodle != null) {
        	$data['codemoodle'] = $codemoodle;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateModule($idModule, $idue, $idTypemodule, $idniveauformation, $idperiode, $idRegime, $idNature, $coefficient, $credit, $Nombredesemaine, $codeue, $titremodule, $noteeleminatoire, $descriptionecue, $nbrscience, $nbroption, $resumer, $codemes, $codemoodle)

		 
    {
        $data = array(
        	            'idue' => $module->idue,
                        'idTypemodule' => $module->idTypemodule,
                        'idniveauformation' => $module->idniveauformation,
                        'idperiode' => $module->idperiode,
                        'idRegime' => $module->idRegime,
                        'idNature' => $module->idNature,
                        'coefficient' => $module->coefficient,
                        'credit' => $module->credit,
                        'Nombredesemaine' => $module->Nombredesemaine,
                        'codeue' => $module->codeue,
                        'titremodule' => $module->titremodule,
                        'noteeleminatoire' => $module->noteeleminatoire,
                        'descriptionecue' => $module->descriptionecue,
                        'nbrscience' => $module->nbrscience,
                        'nbroption' => $module->nbroption,
                        'resumer' => $module->resumer,
                        'codemes' => $module->codemes,
                        'codemoodle' => $module->codemoodle,
                            );
				
		 			$this->update($data, array(idModule => $id));
			
				
				
        
    }
			 
		public function deleteModule($id)
	   
    {
					$this->delete(array('idModule' => $id));
			
				
        
    }

}
