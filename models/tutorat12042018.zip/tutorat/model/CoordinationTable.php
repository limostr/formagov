<?php
 
//		$id=$row->idcoordination;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class CoordinationTable extends AbstractTableGateway
{
    protected $table ='coordination';
    protected $tableName ='coordination';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Coordination);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('coordination')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idcoordination;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idcoordination' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getCoordination($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idcoordination' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchCoordination($idnaturecoordinateur, $idniveauformation, $idpersonnes, $idanneeuniv, $idperiode, $suspondu, $datesuspond, $causesuspond, $docupload)
    {
        $select = $this->getSelect();
                if ($idnaturecoordinateur != null) {
        	$select->where->like('idnaturecoordinateur' ,'%'.$idnaturecoordinateur.'%');
        }
                if ($idniveauformation != null) {
        	$select->where->like('idniveauformation' ,'%'.$idniveauformation.'%');
        }
                if ($idpersonnes != null) {
        	$select->where->like('idpersonnes' ,'%'.$idpersonnes.'%');
        }
                if ($idanneeuniv != null) {
        	$select->where->like('idanneeuniv' ,'%'.$idanneeuniv.'%');
        }
                if ($idperiode != null) {
        	$select->where->like('idperiode' ,'%'.$idperiode.'%');
        }
                if ($suspondu != null) {
        	$select->where->like('suspondu' ,'%'.$suspondu.'%');
        }
                if ($datesuspond != null) {
        	$select->where->like('datesuspond' ,'%'.$datesuspond.'%');
        }
                if ($causesuspond != null) {
        	$select->where->like('causesuspond' ,'%'.$causesuspond.'%');
        }
                if ($docupload != null) {
        	$select->where->like('docupload' ,'%'.$docupload.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveCoordination(Coordination $coordination)
    {
        $data = array(
        	            'idnaturecoordinateur' => $coordination->idnaturecoordinateur,
                        'idniveauformation' => $coordination->idniveauformation,
                        'idpersonnes' => $coordination->idpersonnes,
                        'idanneeuniv' => $coordination->idanneeuniv,
                        'idperiode' => $coordination->idperiode,
                        'suspondu' => $coordination->suspondu,
                        'datesuspond' => $coordination->datesuspond,
                        'causesuspond' => $coordination->causesuspond,
                        'docupload' => $coordination->docupload,
                    );

        $id = (int)$coordination->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getCoordination($id)) {
                $this->update($data, array('idcoordination' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addCoordination($idnaturecoordinateur, $idniveauformation, $idpersonnes, $idanneeuniv, $idperiode = null, $suspondu = null, $datesuspond = null, $causesuspond = null, $docupload = null)
    {
        $data = array(            'idnaturecoordinateur' => $idnaturecoordinateur,
                        'idniveauformation' => $idniveauformation,
                        'idpersonnes' => $idpersonnes,
                        'idanneeuniv' => $idanneeuniv,
                    );
                if ($idperiode != null) {
        	$data['idperiode'] = $idperiode;
        }
                if ($suspondu != null) {
        	$data['suspondu'] = $suspondu;
        }
                if ($datesuspond != null) {
        	$data['datesuspond'] = $datesuspond;
        }
                if ($causesuspond != null) {
        	$data['causesuspond'] = $causesuspond;
        }
                if ($docupload != null) {
        	$data['docupload'] = $docupload;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateCoordination($idcoordination, $idnaturecoordinateur, $idniveauformation, $idpersonnes, $idanneeuniv, $idperiode, $suspondu, $datesuspond, $causesuspond, $docupload)

		 
    {
        $data = array(
        	            'idnaturecoordinateur' => $coordination->idnaturecoordinateur,
                        'idniveauformation' => $coordination->idniveauformation,
                        'idpersonnes' => $coordination->idpersonnes,
                        'idanneeuniv' => $coordination->idanneeuniv,
                        'idperiode' => $coordination->idperiode,
                        'suspondu' => $coordination->suspondu,
                        'datesuspond' => $coordination->datesuspond,
                        'causesuspond' => $coordination->causesuspond,
                        'docupload' => $coordination->docupload,
                            );
				
		 			$this->update($data, array(idcoordination => $id));
			
				
				
        
    }
			 
		public function deleteCoordination($id)
	   
    {
					$this->delete(array('idcoordination' => $id));
			
				
        
    }

}
