<?php
 
//		$id=$row->idinvitations;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class InvitationsTable extends AbstractTableGateway
{
    protected $table ='invitations';
    protected $tableName ='invitations';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Invitations);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('invitations')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idinvitations;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idinvitations' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getInvitations($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idinvitations' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchInvitations($idanneeuniv, $idperiode, $codeinvitation, $textinvitation, $email, $nominviter, $prenominviter)
    {
        $select = $this->getSelect();
                if ($idanneeuniv != null) {
        	$select->where->like('idanneeuniv' ,'%'.$idanneeuniv.'%');
        }
                if ($idperiode != null) {
        	$select->where->like('idperiode' ,'%'.$idperiode.'%');
        }
                if ($codeinvitation != null) {
        	$select->where->like('codeinvitation' ,'%'.$codeinvitation.'%');
        }
                if ($textinvitation != null) {
        	$select->where->like('textinvitation' ,'%'.$textinvitation.'%');
        }
                if ($email != null) {
        	$select->where->like('email' ,'%'.$email.'%');
        }
                if ($nominviter != null) {
        	$select->where->like('nominviter' ,'%'.$nominviter.'%');
        }
                if ($prenominviter != null) {
        	$select->where->like('prenominviter' ,'%'.$prenominviter.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveInvitations(Invitations $invitations)
    {
        $data = array(
        	            'idanneeuniv' => $invitations->idanneeuniv,
                        'idperiode' => $invitations->idperiode,
                        'codeinvitation' => $invitations->codeinvitation,
                        'textinvitation' => $invitations->textinvitation,
                        'email' => $invitations->email,
                        'nominviter' => $invitations->nominviter,
                        'prenominviter' => $invitations->prenominviter,
                    );

        $id = (int)$invitations->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getInvitations($id)) {
                $this->update($data, array('idinvitations' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addInvitations($idanneeuniv, $idperiode, $codeinvitation = null, $textinvitation = null, $email = null, $nominviter = null, $prenominviter = null)
    {
        $data = array( 'idanneeuniv' => $idanneeuniv,
                        'idperiode' => $idperiode,
                    );
        if ($codeinvitation != null) {
        	$data['codeinvitation'] = $codeinvitation;
        }
        if ($textinvitation != null) {
        	$data['textinvitation'] = $textinvitation;
        }
                if ($email != null) {
        	$data['email'] = $email;
        }
                if ($nominviter != null) {
        	$data['nominviter'] = $nominviter;
        }
                if ($prenominviter != null) {
        	$data['prenominviter'] = $prenominviter;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateInvitations($idinvitations, $idanneeuniv, $idperiode, $codeinvitation, $textinvitation, $email, $nominviter, $prenominviter)

		 
    {
        $data = array(
        	            'idanneeuniv' => $invitations->idanneeuniv,
                        'idperiode' => $invitations->idperiode,
                        'codeinvitation' => $invitations->codeinvitation,
                        'textinvitation' => $invitations->textinvitation,
                        'email' => $invitations->email,
                        'nominviter' => $invitations->nominviter,
                        'prenominviter' => $invitations->prenominviter,
                            );
				
		 			$this->update($data, array(idinvitations => $id));
			
				
				
        
    }
			 
		public function deleteInvitations($id)
	   
    {
					$this->delete(array('idinvitations' => $id));
			
				
        
    }

}
