<?php
 
//		$id=$row->iddiplomeensegnier;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class DiplomeensegnierTable extends AbstractTableGateway
{
    protected $table ='diplomeensegnier';
    protected $tableName ='diplomeensegnier';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Diplomeensegnier);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('diplomeensegnier')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->iddiplomeensegnier;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'iddiplomeensegnier' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getDiplomeensegnier($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('iddiplomeensegnier' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchDiplomeensegnier($idetabenseignement, $titreparcour, $domaineparcens, $specialiterparcens)
    {
        $select = $this->getSelect();
                if ($idetabenseignement != null) {
        	$select->where->like('idetabenseignement' ,'%'.$idetabenseignement.'%');
        }
                if ($titreparcour != null) {
        	$select->where->like('titreparcour' ,'%'.$titreparcour.'%');
        }
                if ($domaineparcens != null) {
        	$select->where->like('domaineparcens' ,'%'.$domaineparcens.'%');
        }
                if ($specialiterparcens != null) {
        	$select->where->like('specialiterparcens' ,'%'.$specialiterparcens.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveDiplomeensegnier(Diplomeensegnier $diplomeensegnier)
    {
        $data = array(
        	            'idetabenseignement' => $diplomeensegnier->idetabenseignement,
                        'titreparcour' => $diplomeensegnier->titreparcour,
                        'domaineparcens' => $diplomeensegnier->domaineparcens,
                        'specialiterparcens' => $diplomeensegnier->specialiterparcens,
                    );

        $id = (int)$diplomeensegnier->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getDiplomeensegnier($id)) {
                $this->update($data, array('iddiplomeensegnier' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addDiplomeensegnier($idetabenseignement, $titreparcour = null, $domaineparcens = null, $specialiterparcens = null)
    {
        $data = array(            'idetabenseignement' => $idetabenseignement,
                    );
                if ($titreparcour != null) {
        	$data['titreparcour'] = $titreparcour;
        }
                if ($domaineparcens != null) {
        	$data['domaineparcens'] = $domaineparcens;
        }
                if ($specialiterparcens != null) {
        	$data['specialiterparcens'] = $specialiterparcens;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateDiplomeensegnier($iddiplomeensegnier, $idetabenseignement, $titreparcour, $domaineparcens, $specialiterparcens)

		 
    {
        $data = array(
        	            'idetabenseignement' => $diplomeensegnier->idetabenseignement,
                        'titreparcour' => $diplomeensegnier->titreparcour,
                        'domaineparcens' => $diplomeensegnier->domaineparcens,
                        'specialiterparcens' => $diplomeensegnier->specialiterparcens,
                            );
				
		 			$this->update($data, array(iddiplomeensegnier => $id));
			
				
				
        
    }
			 
		public function deleteDiplomeensegnier($id)
	   
    {
					$this->delete(array('iddiplomeensegnier' => $id));
			
				
        
    }

}
