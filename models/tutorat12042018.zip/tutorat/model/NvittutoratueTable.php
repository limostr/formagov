<?php
	//	$id['idinvitations']=$row->idinvitations;
	//	$id['idModule']=$row->idModule;
		
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class NvittutoratueTable extends AbstractTableGateway
{
    protected $table ='nvittutoratue';
    protected $tableName ='nvittutoratue';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Nvittutoratue);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('nvittutoratue')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
											$id['idinvitations']=$row->idinvitations;
								$id['idModule']=$row->idModule;
								
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
										'idinvitations'=> null,
								'idModule'=> null,
				 
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getNvittutoratue($idinvitations,$idModule)
	    {
        
					$rowset = $this->select(array('idinvitations'=>$idinvitations,'idModule'=>$idModule)); 
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $idinvitations");
        }
        return $row;
    }
    
     public function matchNvittutoratue($idinvitations, $idModule, $statusinvtvalid, $datereponse)
    {
        $select = $this->getSelect();
                if ($idinvitations != null) {
        	$select->where->like('idinvitations' ,'%'.$idinvitations.'%');
        }
                if ($idModule != null) {
        	$select->where->like('idModule' ,'%'.$idModule.'%');
        }
                if ($statusinvtvalid != null) {
        	$select->where->like('statusinvtvalid' ,'%'.$statusinvtvalid.'%');
        }
                if ($datereponse != null) {
        	$select->where->like('datereponse' ,'%'.$datereponse.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveNvittutoratue(Nvittutoratue $nvittutoratue)
    {
        $data = array(
        	            'idinvitations' => $nvittutoratue->idinvitations,
                        'idModule' => $nvittutoratue->idModule,
                        'statusinvtvalid' => $nvittutoratue->statusinvtvalid,
                        'datereponse' => $nvittutoratue->datereponse,
                    );

        $id = (int)$nvittutoratue->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
				if ($this->getNvittutoratue($nvittutoratue->idinvitations,$nvittutoratue->idModule)) {
                $this->update($data, array('idinvitations'=>$nvittutoratue->idinvitations,'idModule'=>$nvittutoratue->idModule));
            } else {
                throw new \Exception('Form id does not exit');
            } 
				
            
        }
    }

    public function addNvittutoratue($idinvitations, $idModule, $statusinvtvalid, $datereponse = null)
    {
        $data = array(            'idinvitations' => $idinvitations,
                        'idModule' => $idModule,
                        'statusinvtvalid' => $statusinvtvalid,
                    );
                if ($datereponse != null) {
        	$data['datereponse'] = $datereponse;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   	    public function updateNvittutoratue($idinvitations , $idModule, $statusinvtvalid, $datereponse)
 
		 
    {
        $data = array(
        	            'idinvitations' => $idinvitations,
                        'idModule' => $idModule,
                        'statusinvtvalid' => $statusinvtvalid,
                        'datereponse' => $datereponse,
                            );
				
		 	 
			$this->update($data, array('idinvitations'=>$idinvitations,'idModule'=>$idModule));
			
				
				
        
    }
			public function deleteNvittutoratue($idinvitations,$idModule)
  
	   
    {
					$this->delete(array('idinvitations'=>$idinvitations,'idModule'=>$idModule));
			 
			
				
        
    }

}
