<?php
	//	$id['idModule']=$row->idModule;
	//	$id['idtypevalidation']=$row->idtypevalidation;
		
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ModulevalidationmoduleTable extends AbstractTableGateway
{
    protected $table ='modulevalidationmodule';
    protected $tableName ='modulevalidationmodule';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Modulevalidationmodule);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('modulevalidationmodule')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
											$id['idModule']=$row->idModule;
								$id['idtypevalidation']=$row->idtypevalidation;
								
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
										'idModule'=> null,
								'idtypevalidation'=> null,
				 
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getModulevalidationmodule($idModule,$idtypevalidation)
	    {
        
					$rowset = $this->select(array('idModule'=>$idModule,'idtypevalidation'=>$idtypevalidation)); 
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchModulevalidationmodule($idModule, $idtypevalidation, $volumehoraireeval, $descmoduleeval)
    {
        $select = $this->getSelect();
                if ($idModule != null) {
        	$select->where->like('idModule' ,'%'.$idModule.'%');
        }
                if ($idtypevalidation != null) {
        	$select->where->like('idtypevalidation' ,'%'.$idtypevalidation.'%');
        }
                if ($volumehoraireeval != null) {
        	$select->where->like('volumehoraireeval' ,'%'.$volumehoraireeval.'%');
        }
                if ($descmoduleeval != null) {
        	$select->where->like('descmoduleeval' ,'%'.$descmoduleeval.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveModulevalidationmodule(Modulevalidationmodule $modulevalidationmodule)
    {
        $data = array(
        	            'idModule' => $modulevalidationmodule->idModule,
                        'idtypevalidation' => $modulevalidationmodule->idtypevalidation,
                        'volumehoraireeval' => $modulevalidationmodule->volumehoraireeval,
                        'descmoduleeval' => $modulevalidationmodule->descmoduleeval,
                    );

        $id = (int)$modulevalidationmodule->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
				if ($this->getModulevalidationmodule($idModule,$idtypevalidation)) {
                $this->update($data, array('idModule'=>$idModule,'idtypevalidation'=>$idtypevalidation));
            } else {
                throw new \Exception('Form id does not exit');
            } 
				
            
        }
    }

    public function addModulevalidationmodule($idModule, $idtypevalidation, $volumehoraireeval = null, $descmoduleeval = null)
    {
        $data = array(            'idModule' => $idModule,
                        'idtypevalidation' => $idtypevalidation,
                    );
                if ($volumehoraireeval != null) {
        	$data['volumehoraireeval'] = $volumehoraireeval;
        }
                if ($descmoduleeval != null) {
        	$data['descmoduleeval'] = $descmoduleeval;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   	    public function updateModulevalidationmodule($idModule,$idtypevalidation, $idModule, $idtypevalidation, $volumehoraireeval, $descmoduleeval)
 
		 
    {
        $data = array(
        	            'idModule' => $modulevalidationmodule->idModule,
                        'idtypevalidation' => $modulevalidationmodule->idtypevalidation,
                        'volumehoraireeval' => $modulevalidationmodule->volumehoraireeval,
                        'descmoduleeval' => $modulevalidationmodule->descmoduleeval,
                            );
				
		 	 
			$this->update($data, array('idModule'=>$idModule,'idtypevalidation'=>$idtypevalidation));
			
				
				
        
    }
			public function deleteModulevalidationmodule($idModule,$idtypevalidation)
  
	   
    {
					$this->delete(array('idModule'=>$idModule,'idtypevalidation'=>$idtypevalidation));
			 
			
				
        
    }

}
