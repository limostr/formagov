<?php
 
//		$id=$row->idetabenseignement;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class EtabenseignementTable extends AbstractTableGateway
{
    protected $table ='etabenseignement';
    protected $tableName ='etabenseignement';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Etabenseignement);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('etabenseignement')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idetabenseignement;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idetabenseignement' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getEtabenseignement($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idetabenseignement' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchEtabenseignement($idpersonnes, $etabnom, $univnom, $pays, $adressetabens, $anneeunivens, $status, $autrinfoetabenseignant, $etabnomar, $univnomar)
    {
        $select = $this->getSelect();
                if ($idpersonnes != null) {
        	$select->where->like('idpersonnes' ,'%'.$idpersonnes.'%');
        }
                if ($etabnom != null) {
        	$select->where->like('etabnom' ,'%'.$etabnom.'%');
        }
                if ($univnom != null) {
        	$select->where->like('univnom' ,'%'.$univnom.'%');
        }
                if ($pays != null) {
        	$select->where->like('pays' ,'%'.$pays.'%');
        }
                if ($adressetabens != null) {
        	$select->where->like('adressetabens' ,'%'.$adressetabens.'%');
        }
                if ($anneeunivens != null) {
        	$select->where->like('anneeunivens' ,'%'.$anneeunivens.'%');
        }
                if ($status != null) {
        	$select->where->like('status' ,'%'.$status.'%');
        }
                if ($autrinfoetabenseignant != null) {
        	$select->where->like('autrinfoetabenseignant' ,'%'.$autrinfoetabenseignant.'%');
        }
                if ($etabnomar != null) {
        	$select->where->like('etabnomar' ,'%'.$etabnomar.'%');
        }
                if ($univnomar != null) {
        	$select->where->like('univnomar' ,'%'.$univnomar.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveEtabenseignement(Etabenseignement $etabenseignement)
    {
        $data = array(
        	            'idpersonnes' => $etabenseignement->idpersonnes,
                        'etabnom' => $etabenseignement->etabnom,
                        'univnom' => $etabenseignement->univnom,
                        'pays' => $etabenseignement->pays,
                        'adressetabens' => $etabenseignement->adressetabens,
                        'anneeunivens' => $etabenseignement->anneeunivens,
                        'status' => $etabenseignement->status,
                        'autrinfoetabenseignant' => $etabenseignement->autrinfoetabenseignant,
                        'etabnomar' => $etabenseignement->etabnomar,
                        'univnomar' => $etabenseignement->univnomar,
                    );

        $id = (int)$etabenseignement->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getEtabenseignement($id)) {
                $this->update($data, array('idetabenseignement' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addEtabenseignement($idpersonnes, $etabnom = null, $univnom = null, $pays = null, $adressetabens = null, $anneeunivens = null, $status = null, $autrinfoetabenseignant = null, $etabnomar = null, $univnomar = null)
    {
        $data = array(            'idpersonnes' => $idpersonnes,
                    );
                if ($etabnom != null) {
        	$data['etabnom'] = $etabnom;
        }
                if ($univnom != null) {
        	$data['univnom'] = $univnom;
        }
                if ($pays != null) {
        	$data['pays'] = $pays;
        }
                if ($adressetabens != null) {
        	$data['adressetabens'] = $adressetabens;
        }
                if ($anneeunivens != null) {
        	$data['anneeunivens'] = $anneeunivens;
        }
                if ($status != null) {
        	$data['status'] = $status;
        }
                if ($autrinfoetabenseignant != null) {
        	$data['autrinfoetabenseignant'] = $autrinfoetabenseignant;
        }
                if ($etabnomar != null) {
        	$data['etabnomar'] = $etabnomar;
        }
                if ($univnomar != null) {
        	$data['univnomar'] = $univnomar;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateEtabenseignement($idetabenseignement, $idpersonnes, $etabnom, $univnom, $pays, $adressetabens, $anneeunivens, $status, $autrinfoetabenseignant, $etabnomar, $univnomar)

		 
    {
        $data = array(
        	            'idpersonnes' => $etabenseignement->idpersonnes,
                        'etabnom' => $etabenseignement->etabnom,
                        'univnom' => $etabenseignement->univnom,
                        'pays' => $etabenseignement->pays,
                        'adressetabens' => $etabenseignement->adressetabens,
                        'anneeunivens' => $etabenseignement->anneeunivens,
                        'status' => $etabenseignement->status,
                        'autrinfoetabenseignant' => $etabenseignement->autrinfoetabenseignant,
                        'etabnomar' => $etabenseignement->etabnomar,
                        'univnomar' => $etabenseignement->univnomar,
                            );
				
		 			$this->update($data, array(idetabenseignement => $id));
			
				
				
        
    }
			 
		public function deleteEtabenseignement($id)
	   
    {
					$this->delete(array('idetabenseignement' => $id));
			
				
        
    }

}
