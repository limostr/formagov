<?php
 
//		$id=$row->idassurerformation;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class AssurerformationTable extends AbstractTableGateway
{
    protected $table ='assurerformation';
    protected $tableName ='assurerformation';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Assurerformation);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('assurerformation')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idassurerformation;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idassurerformation' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getAssurerformation($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idassurerformation' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchAssurerformation($idpersonnes, $idniveauformation, $themformation, $sessionformation, $pays, $publiccible, $lierelearning, $fournisseurformation, $autrinfoassurformation, $datesession, $nmbredejour, $lieravecluvt)
    {
        $select = $this->getSelect();
                if ($idpersonnes != null) {
        	$select->where->like('idpersonnes' ,'%'.$idpersonnes.'%');
        }
                if ($idniveauformation != null) {
        	$select->where->like('idniveauformation' ,'%'.$idniveauformation.'%');
        }
                if ($themformation != null) {
        	$select->where->like('themformation' ,'%'.$themformation.'%');
        }
                if ($sessionformation != null) {
        	$select->where->like('sessionformation' ,'%'.$sessionformation.'%');
        }
                if ($pays != null) {
        	$select->where->like('pays' ,'%'.$pays.'%');
        }
                if ($publiccible != null) {
        	$select->where->like('publiccible' ,'%'.$publiccible.'%');
        }
                if ($lierelearning != null) {
        	$select->where->like('lierelearning' ,'%'.$lierelearning.'%');
        }
                if ($fournisseurformation != null) {
        	$select->where->like('fournisseurformation' ,'%'.$fournisseurformation.'%');
        }
                if ($autrinfoassurformation != null) {
        	$select->where->like('autrinfoassurformation' ,'%'.$autrinfoassurformation.'%');
        }
                if ($datesession != null) {
        	$select->where->like('datesession' ,'%'.$datesession.'%');
        }
                if ($nmbredejour != null) {
        	$select->where->like('nmbredejour' ,'%'.$nmbredejour.'%');
        }
                if ($lieravecluvt != null) {
        	$select->where->like('lieravecluvt' ,'%'.$lieravecluvt.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveAssurerformation(Assurerformation $assurerformation)
    {
        $data = array(
        	            'idpersonnes' => $assurerformation->idpersonnes,
                        'idniveauformation' => $assurerformation->idniveauformation,
                        'themformation' => $assurerformation->themformation,
                        'sessionformation' => $assurerformation->sessionformation,
                        'pays' => $assurerformation->pays,
                        'publiccible' => $assurerformation->publiccible,
                        'lierelearning' => $assurerformation->lierelearning,
                        'fournisseurformation' => $assurerformation->fournisseurformation,
                        'autrinfoassurformation' => $assurerformation->autrinfoassurformation,
                        'datesession' => $assurerformation->datesession,
                        'nmbredejour' => $assurerformation->nmbredejour,
                        'lieravecluvt' => $assurerformation->lieravecluvt,
                    );

        $id = (int)$assurerformation->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getAssurerformation($id)) {
                $this->update($data, array('idassurerformation' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addAssurerformation($idpersonnes, $idniveauformation = null, $themformation = null, $sessionformation = null, $pays = null, $publiccible = null, $lierelearning = null, $fournisseurformation = null, $autrinfoassurformation = null, $datesession = null, $nmbredejour = null, $lieravecluvt = null)
    {
        $data = array(            'idpersonnes' => $idpersonnes,
                    );
                if ($idniveauformation != null) {
        	$data['idniveauformation'] = $idniveauformation;
        }
                if ($themformation != null) {
        	$data['themformation'] = $themformation;
        }
                if ($sessionformation != null) {
        	$data['sessionformation'] = $sessionformation;
        }
                if ($pays != null) {
        	$data['pays'] = $pays;
        }
                if ($publiccible != null) {
        	$data['publiccible'] = $publiccible;
        }
                if ($lierelearning != null) {
        	$data['lierelearning'] = $lierelearning;
        }
                if ($fournisseurformation != null) {
        	$data['fournisseurformation'] = $fournisseurformation;
        }
                if ($autrinfoassurformation != null) {
        	$data['autrinfoassurformation'] = $autrinfoassurformation;
        }
                if ($datesession != null) {
        	$data['datesession'] = $datesession;
        }
                if ($nmbredejour != null) {
        	$data['nmbredejour'] = $nmbredejour;
        }
                if ($lieravecluvt != null) {
        	$data['lieravecluvt'] = $lieravecluvt;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateAssurerformation($idassurerformation, $idpersonnes, $idniveauformation, $themformation, $sessionformation, $pays, $publiccible, $lierelearning, $fournisseurformation, $autrinfoassurformation, $datesession, $nmbredejour, $lieravecluvt)

		 
    {
        $data = array(
        	            'idpersonnes' => $assurerformation->idpersonnes,
                        'idniveauformation' => $assurerformation->idniveauformation,
                        'themformation' => $assurerformation->themformation,
                        'sessionformation' => $assurerformation->sessionformation,
                        'pays' => $assurerformation->pays,
                        'publiccible' => $assurerformation->publiccible,
                        'lierelearning' => $assurerformation->lierelearning,
                        'fournisseurformation' => $assurerformation->fournisseurformation,
                        'autrinfoassurformation' => $assurerformation->autrinfoassurformation,
                        'datesession' => $assurerformation->datesession,
                        'nmbredejour' => $assurerformation->nmbredejour,
                        'lieravecluvt' => $assurerformation->lieravecluvt,
                            );
				
		 			$this->update($data, array(idassurerformation => $id));
			
				
				
        
    }
			 
		public function deleteAssurerformation($id)
	   
    {
					$this->delete(array('idassurerformation' => $id));
			
				
        
    }

}
