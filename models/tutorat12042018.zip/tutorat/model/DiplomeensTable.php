<?php
 
//		$id=$row->iddiplomeens;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class DiplomeensTable extends AbstractTableGateway
{
    protected $table ='diplomeens';
    protected $tableName ='diplomeens';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Diplomeens);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('diplomeens')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->iddiplomeens;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'iddiplomeens' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getDiplomeens($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('iddiplomeens' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchDiplomeens($idpersonnes, $titrediplome, $pays, $etablissement, $dateobtention, $mentiondip, $autreinfodiplome, $titrediplomear, $etablissementar, $paysar, $mentiondipar, $specialiterdiplome, $specialiterdiplomear, $dernierdiplome)
    {
        $select = $this->getSelect();
                if ($idpersonnes != null) {
        	$select->where->like('idpersonnes' ,'%'.$idpersonnes.'%');
        }
                if ($titrediplome != null) {
        	$select->where->like('titrediplome' ,'%'.$titrediplome.'%');
        }
                if ($pays != null) {
        	$select->where->like('pays' ,'%'.$pays.'%');
        }
                if ($etablissement != null) {
        	$select->where->like('etablissement' ,'%'.$etablissement.'%');
        }
                if ($dateobtention != null) {
        	$select->where->like('dateobtention' ,'%'.$dateobtention.'%');
        }
                if ($mentiondip != null) {
        	$select->where->like('mentiondip' ,'%'.$mentiondip.'%');
        }
                if ($autreinfodiplome != null) {
        	$select->where->like('autreinfodiplome' ,'%'.$autreinfodiplome.'%');
        }
                if ($titrediplomear != null) {
        	$select->where->like('titrediplomear' ,'%'.$titrediplomear.'%');
        }
                if ($etablissementar != null) {
        	$select->where->like('etablissementar' ,'%'.$etablissementar.'%');
        }
                if ($paysar != null) {
        	$select->where->like('paysar' ,'%'.$paysar.'%');
        }
                if ($mentiondipar != null) {
        	$select->where->like('mentiondipar' ,'%'.$mentiondipar.'%');
        }
                if ($specialiterdiplome != null) {
        	$select->where->like('specialiterdiplome' ,'%'.$specialiterdiplome.'%');
        }
                if ($specialiterdiplomear != null) {
        	$select->where->like('specialiterdiplomear' ,'%'.$specialiterdiplomear.'%');
        }
                if ($dernierdiplome != null) {
        	$select->where->like('dernierdiplome' ,'%'.$dernierdiplome.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveDiplomeens(Diplomeens $diplomeens)
    {
        $data = array(
        	            'idpersonnes' => $diplomeens->idpersonnes,
                        'titrediplome' => $diplomeens->titrediplome,
                        'pays' => $diplomeens->pays,
                        'etablissement' => $diplomeens->etablissement,
                        'dateobtention' => $diplomeens->dateobtention,
                        'mentiondip' => $diplomeens->mentiondip,
                        'autreinfodiplome' => $diplomeens->autreinfodiplome,
                        'titrediplomear' => $diplomeens->titrediplomear,
                        'etablissementar' => $diplomeens->etablissementar,
                        'paysar' => $diplomeens->paysar,
                        'mentiondipar' => $diplomeens->mentiondipar,
                        'specialiterdiplome' => $diplomeens->specialiterdiplome,
                        'specialiterdiplomear' => $diplomeens->specialiterdiplomear,
                        'dernierdiplome' => $diplomeens->dernierdiplome,
                    );

        $id = (int)$diplomeens->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getDiplomeens($id)) {
                $this->update($data, array('iddiplomeens' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addDiplomeens($idpersonnes, $titrediplome = null, $pays = null, $etablissement = null, $dateobtention = null, $mentiondip = null, $autreinfodiplome = null, $titrediplomear = null, $etablissementar = null, $paysar = null, $mentiondipar = null, $specialiterdiplome = null, $specialiterdiplomear = null, $dernierdiplome = null)
    {
        $data = array(            'idpersonnes' => $idpersonnes,
                    );
                if ($titrediplome != null) {
        	$data['titrediplome'] = $titrediplome;
        }
                if ($pays != null) {
        	$data['pays'] = $pays;
        }
                if ($etablissement != null) {
        	$data['etablissement'] = $etablissement;
        }
                if ($dateobtention != null) {
        	$data['dateobtention'] = $dateobtention;
        }
                if ($mentiondip != null) {
        	$data['mentiondip'] = $mentiondip;
        }
                if ($autreinfodiplome != null) {
        	$data['autreinfodiplome'] = $autreinfodiplome;
        }
                if ($titrediplomear != null) {
        	$data['titrediplomear'] = $titrediplomear;
        }
                if ($etablissementar != null) {
        	$data['etablissementar'] = $etablissementar;
        }
                if ($paysar != null) {
        	$data['paysar'] = $paysar;
        }
                if ($mentiondipar != null) {
        	$data['mentiondipar'] = $mentiondipar;
        }
                if ($specialiterdiplome != null) {
        	$data['specialiterdiplome'] = $specialiterdiplome;
        }
                if ($specialiterdiplomear != null) {
        	$data['specialiterdiplomear'] = $specialiterdiplomear;
        }
                if ($dernierdiplome != null) {
        	$data['dernierdiplome'] = $dernierdiplome;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateDiplomeens($iddiplomeens, $idpersonnes, $titrediplome, $pays, $etablissement, $dateobtention, $mentiondip, $autreinfodiplome, $titrediplomear, $etablissementar, $paysar, $mentiondipar, $specialiterdiplome, $specialiterdiplomear, $dernierdiplome)

		 
    {
        $data = array(
        	            'idpersonnes' => $diplomeens->idpersonnes,
                        'titrediplome' => $diplomeens->titrediplome,
                        'pays' => $diplomeens->pays,
                        'etablissement' => $diplomeens->etablissement,
                        'dateobtention' => $diplomeens->dateobtention,
                        'mentiondip' => $diplomeens->mentiondip,
                        'autreinfodiplome' => $diplomeens->autreinfodiplome,
                        'titrediplomear' => $diplomeens->titrediplomear,
                        'etablissementar' => $diplomeens->etablissementar,
                        'paysar' => $diplomeens->paysar,
                        'mentiondipar' => $diplomeens->mentiondipar,
                        'specialiterdiplome' => $diplomeens->specialiterdiplome,
                        'specialiterdiplomear' => $diplomeens->specialiterdiplomear,
                        'dernierdiplome' => $diplomeens->dernierdiplome,
                            );
				
		 			$this->update($data, array(iddiplomeens => $id));
			
				
				
        
    }
			 
		public function deleteDiplomeens($id)
	   
    {
					$this->delete(array('iddiplomeens' => $id));
			
				
        
    }

}
