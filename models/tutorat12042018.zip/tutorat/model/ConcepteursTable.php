<?php
	//	$id['conceptions_idconceptions']=$row->conceptions_idconceptions;
	//	$id['enseignants_idpersonnes']=$row->enseignants_idpersonnes;
		
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ConcepteursTable extends AbstractTableGateway
{
    protected $table ='concepteurs';
    protected $tableName ='concepteurs';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Concepteurs);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('concepteurs')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
											$id['conceptions_idconceptions']=$row->conceptions_idconceptions;
								$id['enseignants_idpersonnes']=$row->enseignants_idpersonnes;
								
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
										'conceptions_idconceptions'=> null,
								'enseignants_idpersonnes'=> null,
				 
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getConcepteurs($conceptions_idconceptions,$enseignants_idpersonnes)
	    {
        
					$rowset = $this->select(array('conceptions_idconceptions'=>$conceptions_idconceptions,'enseignants_idpersonnes'=>$enseignants_idpersonnes)); 
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchConcepteurs($conceptions_idconceptions, $enseignants_idpersonnes)
    {
        $select = $this->getSelect();
                if ($conceptions_idconceptions != null) {
        	$select->where->like('conceptions_idconceptions' ,'%'.$conceptions_idconceptions.'%');
        }
                if ($enseignants_idpersonnes != null) {
        	$select->where->like('enseignants_idpersonnes' ,'%'.$enseignants_idpersonnes.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveConcepteurs(Concepteurs $concepteurs)
    {
        $data = array(
        	            'conceptions_idconceptions' => $concepteurs->conceptions_idconceptions,
                        'enseignants_idpersonnes' => $concepteurs->enseignants_idpersonnes,
                    );

        $id = (int)$concepteurs->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
				if ($this->getConcepteurs($conceptions_idconceptions,$enseignants_idpersonnes)) {
                $this->update($data, array('conceptions_idconceptions'=>$conceptions_idconceptions,'enseignants_idpersonnes'=>$enseignants_idpersonnes));
            } else {
                throw new \Exception('Form id does not exit');
            } 
				
            
        }
    }

    public function addConcepteurs($conceptions_idconceptions, $enseignants_idpersonnes)
    {
        $data = array(            'conceptions_idconceptions' => $conceptions_idconceptions,
                        'enseignants_idpersonnes' => $enseignants_idpersonnes,
                    );
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   	    public function updateConcepteurs($conceptions_idconceptions,$enseignants_idpersonnes, $conceptions_idconceptions, $enseignants_idpersonnes)
 
		 
    {
        $data = array(
        	            'conceptions_idconceptions' => $concepteurs->conceptions_idconceptions,
                        'enseignants_idpersonnes' => $concepteurs->enseignants_idpersonnes,
                            );
				
		 	 
			$this->update($data, array('conceptions_idconceptions'=>$conceptions_idconceptions,'enseignants_idpersonnes'=>$enseignants_idpersonnes));
			
				
				
        
    }
			public function deleteConcepteurs($conceptions_idconceptions,$enseignants_idpersonnes)
  
	   
    {
					$this->delete(array('conceptions_idconceptions'=>$conceptions_idconceptions,'enseignants_idpersonnes'=>$enseignants_idpersonnes));
			 
			
				
        
    }

}
