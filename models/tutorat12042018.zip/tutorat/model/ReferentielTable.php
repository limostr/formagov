<?php
	//	$id['idobjective']=$row->idobjective;
	//	$id['idformations']=$row->idformations;
		
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ReferentielTable extends AbstractTableGateway
{
    protected $table ='referentiel';
    protected $tableName ='referentiel';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Referentiel);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('referentiel')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
											$id['idobjective']=$row->idobjective;
								$id['idformations']=$row->idformations;
								
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
										'idobjective'=> null,
								'idformations'=> null,
				 
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getReferentiel($idobjective,$idformations)
	    {
        
					$rowset = $this->select(array('idobjective'=>$idobjective,'idformations'=>$idformations)); 
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchReferentiel($idobjective, $idformations)
    {
        $select = $this->getSelect();
                if ($idobjective != null) {
        	$select->where->like('idobjective' ,'%'.$idobjective.'%');
        }
                if ($idformations != null) {
        	$select->where->like('idformations' ,'%'.$idformations.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveReferentiel(Referentiel $referentiel)
    {
        $data = array(
        	            'idobjective' => $referentiel->idobjective,
                        'idformations' => $referentiel->idformations,
                    );

        $id = (int)$referentiel->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
				if ($this->getReferentiel($idobjective,$idformations)) {
                $this->update($data, array('idobjective'=>$idobjective,'idformations'=>$idformations));
            } else {
                throw new \Exception('Form id does not exit');
            } 
				
            
        }
    }

    public function addReferentiel($idobjective, $idformations)
    {
        $data = array(            'idobjective' => $idobjective,
                        'idformations' => $idformations,
                    );
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   	    public function updateReferentiel($idobjective,$idformations, $idobjective, $idformations)
 
		 
    {
        $data = array(
        	            'idobjective' => $referentiel->idobjective,
                        'idformations' => $referentiel->idformations,
                            );
				
		 	 
			$this->update($data, array('idobjective'=>$idobjective,'idformations'=>$idformations));
			
				
				
        
    }
			public function deleteReferentiel($idobjective,$idformations)
  
	   
    {
					$this->delete(array('idobjective'=>$idobjective,'idformations'=>$idformations));
			 
			
				
        
    }

}
