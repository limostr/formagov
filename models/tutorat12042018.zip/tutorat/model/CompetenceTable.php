<?php
 
//		$id=$row->idcompetence;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class CompetenceTable extends AbstractTableGateway
{
    protected $table ='competence';
    protected $tableName ='competence';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Competence);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('competence')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idcompetence;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idcompetence' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getCompetence($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idcompetence' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchCompetence($idperecompetence, $idobjective, $titrecompetence, $desccompetence, $obligatoireobj, $poidscompetence)
    {
        $select = $this->getSelect();
                if ($idperecompetence != null) {
        	$select->where->like('idperecompetence' ,'%'.$idperecompetence.'%');
        }
                if ($idobjective != null) {
        	$select->where->like('idobjective' ,'%'.$idobjective.'%');
        }
                if ($titrecompetence != null) {
        	$select->where->like('titrecompetence' ,'%'.$titrecompetence.'%');
        }
                if ($desccompetence != null) {
        	$select->where->like('desccompetence' ,'%'.$desccompetence.'%');
        }
                if ($obligatoireobj != null) {
        	$select->where->like('obligatoireobj' ,'%'.$obligatoireobj.'%');
        }
                if ($poidscompetence != null) {
        	$select->where->like('poidscompetence' ,'%'.$poidscompetence.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveCompetence(Competence $competence)
    {
        $data = array(
        	            'idperecompetence' => $competence->idperecompetence,
                        'idobjective' => $competence->idobjective,
                        'titrecompetence' => $competence->titrecompetence,
                        'desccompetence' => $competence->desccompetence,
                        'obligatoireobj' => $competence->obligatoireobj,
                        'poidscompetence' => $competence->poidscompetence,
                    );

        $id = (int)$competence->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getCompetence($id)) {
                $this->update($data, array('idcompetence' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addCompetence($idobjective, $idperecompetence = null, $titrecompetence = null, $desccompetence = null, $obligatoireobj = null, $poidscompetence = null)
    {
        $data = array(            'idobjective' => $idobjective,
                    );
                if ($idperecompetence != null) {
        	$data['idperecompetence'] = $idperecompetence;
        }
                if ($titrecompetence != null) {
        	$data['titrecompetence'] = $titrecompetence;
        }
                if ($desccompetence != null) {
        	$data['desccompetence'] = $desccompetence;
        }
                if ($obligatoireobj != null) {
        	$data['obligatoireobj'] = $obligatoireobj;
        }
                if ($poidscompetence != null) {
        	$data['poidscompetence'] = $poidscompetence;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateCompetence($idcompetence, $idperecompetence, $idobjective, $titrecompetence, $desccompetence, $obligatoireobj, $poidscompetence)

		 
    {
        $data = array(
        	            'idperecompetence' => $competence->idperecompetence,
                        'idobjective' => $competence->idobjective,
                        'titrecompetence' => $competence->titrecompetence,
                        'desccompetence' => $competence->desccompetence,
                        'obligatoireobj' => $competence->obligatoireobj,
                        'poidscompetence' => $competence->poidscompetence,
                            );
				
		 			$this->update($data, array(idcompetence => $id));
			
				
				
        
    }
			 
		public function deleteCompetence($id)
	   
    {
					$this->delete(array('idcompetence' => $id));
			
				
        
    }

}
