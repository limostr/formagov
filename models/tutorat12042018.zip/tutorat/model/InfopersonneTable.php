<?php
 
//		$id=$row->idinfopersonne;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class InfopersonneTable extends AbstractTableGateway
{
    protected $table ='infopersonne';
    protected $tableName ='infopersonne';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Infopersonne);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('infopersonne')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idinfopersonne;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idinfopersonne' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getInfopersonne($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idinfopersonne' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchInfopersonne($idpersonnes, $idlangue, $non, $prenom, $ville, $pays, $codepostal, $adress, $lieudenaissance, $autreinfo)
    {
        $select = $this->getSelect();
                if ($idpersonnes != null) {
        	$select->where->like('idpersonnes' ,'%'.$idpersonnes.'%');
        }
                if ($idlangue != null) {
        	$select->where->like('idlangue' ,'%'.$idlangue.'%');
        }
                if ($non != null) {
        	$select->where->like('non' ,'%'.$non.'%');
        }
                if ($prenom != null) {
        	$select->where->like('prenom' ,'%'.$prenom.'%');
        }
                if ($ville != null) {
        	$select->where->like('ville' ,'%'.$ville.'%');
        }
                if ($pays != null) {
        	$select->where->like('pays' ,'%'.$pays.'%');
        }
                if ($codepostal != null) {
        	$select->where->like('codepostal' ,'%'.$codepostal.'%');
        }
                if ($adress != null) {
        	$select->where->like('adress' ,'%'.$adress.'%');
        }
                if ($lieudenaissance != null) {
        	$select->where->like('lieudenaissance' ,'%'.$lieudenaissance.'%');
        }
                if ($autreinfo != null) {
        	$select->where->like('autreinfo' ,'%'.$autreinfo.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveInfopersonne(Infopersonne $infopersonne)
    {
        $data = array(
        	            'idpersonnes' => $infopersonne->idpersonnes,
                        'idlangue' => $infopersonne->idlangue,
                        'non' => $infopersonne->non,
                        'prenom' => $infopersonne->prenom,
                        'ville' => $infopersonne->ville,
                        'pays' => $infopersonne->pays,
                        'codepostal' => $infopersonne->codepostal,
                        'adress' => $infopersonne->adress,
                        'lieudenaissance' => $infopersonne->lieudenaissance,
                        'autreinfo' => $infopersonne->autreinfo,
                    );

        $id = (int)$infopersonne->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getInfopersonne($id)) {
                $this->update($data, array('idinfopersonne' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addInfopersonne($idpersonnes, $idlangue, $non = null, $prenom = null, $ville = null, $pays = null, $codepostal = null, $adress = null, $lieudenaissance = null, $autreinfo = null)
    {
        $data = array(            'idpersonnes' => $idpersonnes,
                        'idlangue' => $idlangue,
                    );
                if ($non != null) {
        	$data['non'] = $non;
        }
                if ($prenom != null) {
        	$data['prenom'] = $prenom;
        }
                if ($ville != null) {
        	$data['ville'] = $ville;
        }
                if ($pays != null) {
        	$data['pays'] = $pays;
        }
                if ($codepostal != null) {
        	$data['codepostal'] = $codepostal;
        }
                if ($adress != null) {
        	$data['adress'] = $adress;
        }
                if ($lieudenaissance != null) {
        	$data['lieudenaissance'] = $lieudenaissance;
        }
                if ($autreinfo != null) {
        	$data['autreinfo'] = $autreinfo;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateInfopersonne($idinfopersonne, $idpersonnes, $idlangue, $non, $prenom, $ville, $pays, $codepostal, $adress, $lieudenaissance, $autreinfo)

		 
    {
        $data = array(
        	            'idpersonnes' => $infopersonne->idpersonnes,
                        'idlangue' => $infopersonne->idlangue,
                        'non' => $infopersonne->non,
                        'prenom' => $infopersonne->prenom,
                        'ville' => $infopersonne->ville,
                        'pays' => $infopersonne->pays,
                        'codepostal' => $infopersonne->codepostal,
                        'adress' => $infopersonne->adress,
                        'lieudenaissance' => $infopersonne->lieudenaissance,
                        'autreinfo' => $infopersonne->autreinfo,
                            );
				
		 			$this->update($data, array(idinfopersonne => $id));
			
				
				
        
    }
			 
		public function deleteInfopersonne($id)
	   
    {
					$this->delete(array('idinfopersonne' => $id));
			
				
        
    }

}
