<?php
 
//		$id=$row->idtraveaux;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class TraveauxTable extends AbstractTableGateway
{
    protected $table ='traveaux';
    protected $tableName ='traveaux';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Traveaux);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('traveaux')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idtraveaux;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idtraveaux' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getTraveaux($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idtraveaux' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchTraveaux($labeltrav, $desctrav)
    {
        $select = $this->getSelect();
                if ($labeltrav != null) {
        	$select->where->like('labeltrav' ,'%'.$labeltrav.'%');
        }
                if ($desctrav != null) {
        	$select->where->like('desctrav' ,'%'.$desctrav.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveTraveaux(Traveaux $traveaux)
    {
        $data = array(
        	            'labeltrav' => $traveaux->labeltrav,
                        'desctrav' => $traveaux->desctrav,
                    );

        $id = (int)$traveaux->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getTraveaux($id)) {
                $this->update($data, array('idtraveaux' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addTraveaux($labeltrav = null, $desctrav = null)
    {
        $data = array(        );
                if ($labeltrav != null) {
        	$data['labeltrav'] = $labeltrav;
        }
                if ($desctrav != null) {
        	$data['desctrav'] = $desctrav;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateTraveaux($idtraveaux, $labeltrav, $desctrav)

		 
    {
        $data = array(
        	            'labeltrav' => $traveaux->labeltrav,
                        'desctrav' => $traveaux->desctrav,
                            );
				
		 			$this->update($data, array(idtraveaux => $id));
			
				
				
        
    }
			 
		public function deleteTraveaux($id)
	   
    {
					$this->delete(array('idtraveaux' => $id));
			
				
        
    }

}
