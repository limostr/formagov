<?php
 
//		$id=$row->idactiviter;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ActiviterTable extends AbstractTableGateway
{
    protected $table ='activiter';
    protected $tableName ='activiter';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Activiter);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('activiter')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idactiviter;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idactiviter' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getActiviter($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idactiviter' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchActiviter($idpereactiviter, $idcompetence, $titreactivite, $descactivite, $obligatoireactivite, $poidsobjective)
    {
        $select = $this->getSelect();
                if ($idpereactiviter != null) {
        	$select->where->like('idpereactiviter' ,'%'.$idpereactiviter.'%');
        }
                if ($idcompetence != null) {
        	$select->where->like('idcompetence' ,'%'.$idcompetence.'%');
        }
                if ($titreactivite != null) {
        	$select->where->like('titreactivite' ,'%'.$titreactivite.'%');
        }
                if ($descactivite != null) {
        	$select->where->like('descactivite' ,'%'.$descactivite.'%');
        }
                if ($obligatoireactivite != null) {
        	$select->where->like('obligatoireactivite' ,'%'.$obligatoireactivite.'%');
        }
                if ($poidsobjective != null) {
        	$select->where->like('poidsobjective' ,'%'.$poidsobjective.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveActiviter(Activiter $activiter)
    {
        $data = array(
        	            'idpereactiviter' => $activiter->idpereactiviter,
                        'idcompetence' => $activiter->idcompetence,
                        'titreactivite' => $activiter->titreactivite,
                        'descactivite' => $activiter->descactivite,
                        'obligatoireactivite' => $activiter->obligatoireactivite,
                        'poidsobjective' => $activiter->poidsobjective,
                    );

        $id = (int)$activiter->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getActiviter($id)) {
                $this->update($data, array('idactiviter' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addActiviter($idcompetence, $idpereactiviter = null, $titreactivite = null, $descactivite = null, $obligatoireactivite = null, $poidsobjective = null)
    {
        $data = array(            'idcompetence' => $idcompetence,
                    );
                if ($idpereactiviter != null) {
        	$data['idpereactiviter'] = $idpereactiviter;
        }
                if ($titreactivite != null) {
        	$data['titreactivite'] = $titreactivite;
        }
                if ($descactivite != null) {
        	$data['descactivite'] = $descactivite;
        }
                if ($obligatoireactivite != null) {
        	$data['obligatoireactivite'] = $obligatoireactivite;
        }
                if ($poidsobjective != null) {
        	$data['poidsobjective'] = $poidsobjective;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateActiviter($idactiviter, $idpereactiviter, $idcompetence, $titreactivite, $descactivite, $obligatoireactivite, $poidsobjective)

		 
    {
        $data = array(
        	            'idpereactiviter' => $activiter->idpereactiviter,
                        'idcompetence' => $activiter->idcompetence,
                        'titreactivite' => $activiter->titreactivite,
                        'descactivite' => $activiter->descactivite,
                        'obligatoireactivite' => $activiter->obligatoireactivite,
                        'poidsobjective' => $activiter->poidsobjective,
                            );
				
		 			$this->update($data, array(idactiviter => $id));
			
				
				
        
    }
			 
		public function deleteActiviter($id)
	   
    {
					$this->delete(array('idactiviter' => $id));
			
				
        
    }

}
