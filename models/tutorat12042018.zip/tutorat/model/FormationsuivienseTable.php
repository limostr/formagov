<?php
 
//		$id=$row->idformationsuiviense;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class FormationsuivienseTable extends AbstractTableGateway
{
    protected $table ='formationsuiviense';
    protected $tableName ='formationsuiviense';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Formationsuiviense);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('formationsuiviense')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idformationsuiviense;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idformationsuiviense' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getFormationsuiviense($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idformationsuiviense' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchFormationsuiviense($idpersonnes, $idniveauformation, $labelformens, $sessionformationsevi, $dateformationens, $attestation, $scoreformsuivi, $autreinfoformsuiviuvt)
    {
        $select = $this->getSelect();
                if ($idpersonnes != null) {
        	$select->where->like('idpersonnes' ,'%'.$idpersonnes.'%');
        }
                if ($idniveauformation != null) {
        	$select->where->like('idniveauformation' ,'%'.$idniveauformation.'%');
        }
                if ($labelformens != null) {
        	$select->where->like('labelformens' ,'%'.$labelformens.'%');
        }
                if ($sessionformationsevi != null) {
        	$select->where->like('sessionformationsevi' ,'%'.$sessionformationsevi.'%');
        }
                if ($dateformationens != null) {
        	$select->where->like('dateformationens' ,'%'.$dateformationens.'%');
        }
                if ($attestation != null) {
        	$select->where->like('attestation' ,'%'.$attestation.'%');
        }
                if ($scoreformsuivi != null) {
        	$select->where->like('scoreformsuivi' ,'%'.$scoreformsuivi.'%');
        }
                if ($autreinfoformsuiviuvt != null) {
        	$select->where->like('autreinfoformsuiviuvt' ,'%'.$autreinfoformsuiviuvt.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveFormationsuiviense(Formationsuiviense $formationsuiviense)
    {
        $data = array(
        	            'idpersonnes' => $formationsuiviense->idpersonnes,
                        'idniveauformation' => $formationsuiviense->idniveauformation,
                        'labelformens' => $formationsuiviense->labelformens,
                        'sessionformationsevi' => $formationsuiviense->sessionformationsevi,
                        'dateformationens' => $formationsuiviense->dateformationens,
                        'attestation' => $formationsuiviense->attestation,
                        'scoreformsuivi' => $formationsuiviense->scoreformsuivi,
                        'autreinfoformsuiviuvt' => $formationsuiviense->autreinfoformsuiviuvt,
                    );

        $id = (int)$formationsuiviense->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getFormationsuiviense($id)) {
                $this->update($data, array('idformationsuiviense' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addFormationsuiviense($idpersonnes, $idniveauformation = null, $labelformens = null, $sessionformationsevi = null, $dateformationens = null, $attestation = null, $scoreformsuivi = null, $autreinfoformsuiviuvt = null)
    {
        $data = array(            'idpersonnes' => $idpersonnes,
                    );
                if ($idniveauformation != null) {
        	$data['idniveauformation'] = $idniveauformation;
        }
                if ($labelformens != null) {
        	$data['labelformens'] = $labelformens;
        }
                if ($sessionformationsevi != null) {
        	$data['sessionformationsevi'] = $sessionformationsevi;
        }
                if ($dateformationens != null) {
        	$data['dateformationens'] = $dateformationens;
        }
                if ($attestation != null) {
        	$data['attestation'] = $attestation;
        }
                if ($scoreformsuivi != null) {
        	$data['scoreformsuivi'] = $scoreformsuivi;
        }
                if ($autreinfoformsuiviuvt != null) {
        	$data['autreinfoformsuiviuvt'] = $autreinfoformsuiviuvt;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateFormationsuiviense($idformationsuiviense, $idpersonnes, $idniveauformation, $labelformens, $sessionformationsevi, $dateformationens, $attestation, $scoreformsuivi, $autreinfoformsuiviuvt)

		 
    {
        $data = array(
        	            'idpersonnes' => $formationsuiviense->idpersonnes,
                        'idniveauformation' => $formationsuiviense->idniveauformation,
                        'labelformens' => $formationsuiviense->labelformens,
                        'sessionformationsevi' => $formationsuiviense->sessionformationsevi,
                        'dateformationens' => $formationsuiviense->dateformationens,
                        'attestation' => $formationsuiviense->attestation,
                        'scoreformsuivi' => $formationsuiviense->scoreformsuivi,
                        'autreinfoformsuiviuvt' => $formationsuiviense->autreinfoformsuiviuvt,
                            );
				
		 			$this->update($data, array(idformationsuiviense => $id));
			
				
				
        
    }
			 
		public function deleteFormationsuiviense($id)
	   
    {
					$this->delete(array('idformationsuiviense' => $id));
			
				
        
    }

}
