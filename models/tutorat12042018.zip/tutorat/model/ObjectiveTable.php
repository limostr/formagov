<?php
 
//		$id=$row->idobjective;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ObjectiveTable extends AbstractTableGateway
{
    protected $table ='objective';
    protected $tableName ='objective';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Objective);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('objective')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idobjective;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idobjective' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getObjective($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idobjective' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchObjective($idpereobjective, $codeobj, $titreobjective, $descobjective, $obligatoireobj, $poidsobjective)
    {
        $select = $this->getSelect();
                if ($idpereobjective != null) {
        	$select->where->like('idpereobjective' ,'%'.$idpereobjective.'%');
        }
                if ($codeobj != null) {
        	$select->where->like('codeobj' ,'%'.$codeobj.'%');
        }
                if ($titreobjective != null) {
        	$select->where->like('titreobjective' ,'%'.$titreobjective.'%');
        }
                if ($descobjective != null) {
        	$select->where->like('descobjective' ,'%'.$descobjective.'%');
        }
                if ($obligatoireobj != null) {
        	$select->where->like('obligatoireobj' ,'%'.$obligatoireobj.'%');
        }
                if ($poidsobjective != null) {
        	$select->where->like('poidsobjective' ,'%'.$poidsobjective.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveObjective(Objective $objective)
    {
        $data = array(
        	            'idpereobjective' => $objective->idpereobjective,
                        'codeobj' => $objective->codeobj,
                        'titreobjective' => $objective->titreobjective,
                        'descobjective' => $objective->descobjective,
                        'obligatoireobj' => $objective->obligatoireobj,
                        'poidsobjective' => $objective->poidsobjective,
                    );

        $id = (int)$objective->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getObjective($id)) {
                $this->update($data, array('idobjective' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addObjective($idpereobjective = null, $codeobj = null, $titreobjective = null, $descobjective = null, $obligatoireobj = null, $poidsobjective = null)
    {
        $data = array(        );
                if ($idpereobjective != null) {
        	$data['idpereobjective'] = $idpereobjective;
        }
                if ($codeobj != null) {
        	$data['codeobj'] = $codeobj;
        }
                if ($titreobjective != null) {
        	$data['titreobjective'] = $titreobjective;
        }
                if ($descobjective != null) {
        	$data['descobjective'] = $descobjective;
        }
                if ($obligatoireobj != null) {
        	$data['obligatoireobj'] = $obligatoireobj;
        }
                if ($poidsobjective != null) {
        	$data['poidsobjective'] = $poidsobjective;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateObjective($idobjective, $idpereobjective, $codeobj, $titreobjective, $descobjective, $obligatoireobj, $poidsobjective)

		 
    {
        $data = array(
        	            'idpereobjective' => $objective->idpereobjective,
                        'codeobj' => $objective->codeobj,
                        'titreobjective' => $objective->titreobjective,
                        'descobjective' => $objective->descobjective,
                        'obligatoireobj' => $objective->obligatoireobj,
                        'poidsobjective' => $objective->poidsobjective,
                            );
				
		 			$this->update($data, array(idobjective => $id));
			
				
				
        
    }
			 
		public function deleteObjective($id)
	   
    {
					$this->delete(array('idobjective' => $id));
			
				
        
    }

}
