<?php
 
//		$id=$row->idconceptions;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ConceptionsTable extends AbstractTableGateway
{
    protected $table ='conceptions';
    protected $tableName ='conceptions';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Conceptions);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('conceptions')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idconceptions;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idconceptions' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getConceptions($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idconceptions' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchConceptions($idModule, $datecreation)
    {
        $select = $this->getSelect();
                if ($idModule != null) {
        	$select->where->like('idModule' ,'%'.$idModule.'%');
        }
                if ($datecreation != null) {
        	$select->where->like('datecreation' ,'%'.$datecreation.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveConceptions(Conceptions $conceptions)
    {
        $data = array(
        	            'idModule' => $conceptions->idModule,
                        'datecreation' => $conceptions->datecreation,
                    );

        $id = (int)$conceptions->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getConceptions($id)) {
                $this->update($data, array('idconceptions' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addConceptions($idModule = null, $datecreation = null)
    {
        $data = array(        );
                if ($idModule != null) {
        	$data['idModule'] = $idModule;
        }
                if ($datecreation != null) {
        	$data['datecreation'] = $datecreation;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateConceptions($idconceptions, $idModule, $datecreation)

		 
    {
        $data = array(
        	            'idModule' => $conceptions->idModule,
                        'datecreation' => $conceptions->datecreation,
                            );
				
		 			$this->update($data, array(idconceptions => $id));
			
				
				
        
    }
			 
		public function deleteConceptions($id)
	   
    {
					$this->delete(array('idconceptions' => $id));
			
				
        
    }

}
