<?php
	//	$id['idpersonnes']=$row->idpersonnes;
	//	$id['iddocumentofficiel']=$row->iddocumentofficiel;
		
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class DepotdocensTable extends AbstractTableGateway
{
    protected $table ='depotdocens';
    protected $tableName ='depotdocens';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Depotdocens);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('depotdocens')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
											$id['idpersonnes']=$row->idpersonnes;
								$id['iddocumentofficiel']=$row->iddocumentofficiel;
								
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
										'idpersonnes'=> null,
								'iddocumentofficiel'=> null,
				 
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getDepotdocens($idpersonnes,$iddocumentofficiel)
	    {
        
					$rowset = $this->select(array('idpersonnes'=>$idpersonnes,'iddocumentofficiel'=>$iddocumentofficiel)); 
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchDepotdocens($idpersonnes, $iddocumentofficiel, $datedepot, $validate, $remarquedoc, $autreinfodepot)
    {
        $select = $this->getSelect();
                if ($idpersonnes != null) {
        	$select->where->like('idpersonnes' ,'%'.$idpersonnes.'%');
        }
                if ($iddocumentofficiel != null) {
        	$select->where->like('iddocumentofficiel' ,'%'.$iddocumentofficiel.'%');
        }
                if ($datedepot != null) {
        	$select->where->like('datedepot' ,'%'.$datedepot.'%');
        }
                if ($validate != null) {
        	$select->where->like('validate' ,'%'.$validate.'%');
        }
                if ($remarquedoc != null) {
        	$select->where->like('remarquedoc' ,'%'.$remarquedoc.'%');
        }
                if ($autreinfodepot != null) {
        	$select->where->like('autreinfodepot' ,'%'.$autreinfodepot.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveDepotdocens(Depotdocens $depotdocens)
    {
        $data = array(
        	            'idpersonnes' => $depotdocens->idpersonnes,
                        'iddocumentofficiel' => $depotdocens->iddocumentofficiel,
                        'datedepot' => $depotdocens->datedepot,
                        'validate' => $depotdocens->validate,
                        'remarquedoc' => $depotdocens->remarquedoc,
                        'autreinfodepot' => $depotdocens->autreinfodepot,
                    );

        $id = (int)$depotdocens->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
				if ($this->getDepotdocens($idpersonnes,$iddocumentofficiel)) {
                $this->update($data, array('idpersonnes'=>$idpersonnes,'iddocumentofficiel'=>$iddocumentofficiel));
            } else {
                throw new \Exception('Form id does not exit');
            } 
				
            
        }
    }

    public function addDepotdocens($idpersonnes, $iddocumentofficiel, $datedepot = null, $validate = null, $remarquedoc = null, $autreinfodepot = null)
    {
        $data = array(            'idpersonnes' => $idpersonnes,
                        'iddocumentofficiel' => $iddocumentofficiel,
                    );
                if ($datedepot != null) {
        	$data['datedepot'] = $datedepot;
        }
                if ($validate != null) {
        	$data['validate'] = $validate;
        }
                if ($remarquedoc != null) {
        	$data['remarquedoc'] = $remarquedoc;
        }
                if ($autreinfodepot != null) {
        	$data['autreinfodepot'] = $autreinfodepot;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   	    public function updateDepotdocens($idpersonnes,$iddocumentofficiel, $idpersonnes, $iddocumentofficiel, $datedepot, $validate, $remarquedoc, $autreinfodepot)
 
		 
    {
        $data = array(
        	            'idpersonnes' => $depotdocens->idpersonnes,
                        'iddocumentofficiel' => $depotdocens->iddocumentofficiel,
                        'datedepot' => $depotdocens->datedepot,
                        'validate' => $depotdocens->validate,
                        'remarquedoc' => $depotdocens->remarquedoc,
                        'autreinfodepot' => $depotdocens->autreinfodepot,
                            );
				
		 	 
			$this->update($data, array('idpersonnes'=>$idpersonnes,'iddocumentofficiel'=>$iddocumentofficiel));
			
				
				
        
    }
			public function deleteDepotdocens($idpersonnes,$iddocumentofficiel)
  
	   
    {
					$this->delete(array('idpersonnes'=>$idpersonnes,'iddocumentofficiel'=>$iddocumentofficiel));
			 
			
				
        
    }

}
