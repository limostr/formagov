<?php
 
//		$id=$row->iddocumentofficiel;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class DocumentofficielTable extends AbstractTableGateway
{
    protected $table ='documentofficiel';
    protected $tableName ='documentofficiel';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Documentofficiel);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('documentofficiel')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->iddocumentofficiel;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'iddocumentofficiel' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getDocumentofficiel($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('iddocumentofficiel' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchDocumentofficiel($idtypedocofficiel, $titredoc, $descdoc, $docobligatoire, $autreinfodocoff)
    {
        $select = $this->getSelect();
                if ($idtypedocofficiel != null) {
        	$select->where->like('idtypedocofficiel' ,'%'.$idtypedocofficiel.'%');
        }
                if ($titredoc != null) {
        	$select->where->like('titredoc' ,'%'.$titredoc.'%');
        }
                if ($descdoc != null) {
        	$select->where->like('descdoc' ,'%'.$descdoc.'%');
        }
                if ($docobligatoire != null) {
        	$select->where->like('docobligatoire' ,'%'.$docobligatoire.'%');
        }
                if ($autreinfodocoff != null) {
        	$select->where->like('autreinfodocoff' ,'%'.$autreinfodocoff.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveDocumentofficiel(Documentofficiel $documentofficiel)
    {
        $data = array(
        	            'idtypedocofficiel' => $documentofficiel->idtypedocofficiel,
                        'titredoc' => $documentofficiel->titredoc,
                        'descdoc' => $documentofficiel->descdoc,
                        'docobligatoire' => $documentofficiel->docobligatoire,
                        'autreinfodocoff' => $documentofficiel->autreinfodocoff,
                    );

        $id = (int)$documentofficiel->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getDocumentofficiel($id)) {
                $this->update($data, array('iddocumentofficiel' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addDocumentofficiel($idtypedocofficiel, $titredoc = null, $descdoc = null, $docobligatoire = null, $autreinfodocoff = null)
    {
        $data = array(            'idtypedocofficiel' => $idtypedocofficiel,
                    );
                if ($titredoc != null) {
        	$data['titredoc'] = $titredoc;
        }
                if ($descdoc != null) {
        	$data['descdoc'] = $descdoc;
        }
                if ($docobligatoire != null) {
        	$data['docobligatoire'] = $docobligatoire;
        }
                if ($autreinfodocoff != null) {
        	$data['autreinfodocoff'] = $autreinfodocoff;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateDocumentofficiel($iddocumentofficiel, $idtypedocofficiel, $titredoc, $descdoc, $docobligatoire, $autreinfodocoff)

		 
    {
        $data = array(
        	            'idtypedocofficiel' => $documentofficiel->idtypedocofficiel,
                        'titredoc' => $documentofficiel->titredoc,
                        'descdoc' => $documentofficiel->descdoc,
                        'docobligatoire' => $documentofficiel->docobligatoire,
                        'autreinfodocoff' => $documentofficiel->autreinfodocoff,
                            );
				
		 			$this->update($data, array(iddocumentofficiel => $id));
			
				
				
        
    }
			 
		public function deleteDocumentofficiel($id)
	   
    {
					$this->delete(array('iddocumentofficiel' => $id));
			
				
        
    }

}
