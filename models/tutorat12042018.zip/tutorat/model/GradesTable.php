<?php
 
//		$id=$row->idgrades;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class GradesTable extends AbstractTableGateway
{
    protected $table ='grades';
    protected $tableName ='grades';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Grades);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('grades')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idgrades;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idgrades' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getGrades($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idgrades' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchGrades($labelgrade, $descgrade, $abrevgrade, $poidsgrade)
    {
        $select = $this->getSelect();
                if ($labelgrade != null) {
        	$select->where->like('labelgrade' ,'%'.$labelgrade.'%');
        }
                if ($descgrade != null) {
        	$select->where->like('descgrade' ,'%'.$descgrade.'%');
        }
                if ($abrevgrade != null) {
        	$select->where->like('abrevgrade' ,'%'.$abrevgrade.'%');
        }
                if ($poidsgrade != null) {
        	$select->where->like('poidsgrade' ,'%'.$poidsgrade.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveGrades(Grades $grades)
    {
        $data = array(
        	            'labelgrade' => $grades->labelgrade,
                        'descgrade' => $grades->descgrade,
                        'abrevgrade' => $grades->abrevgrade,
                        'poidsgrade' => $grades->poidsgrade,
                    );

        $id = (int)$grades->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getGrades($id)) {
                $this->update($data, array('idgrades' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addGrades($labelgrade = null, $descgrade = null, $abrevgrade = null, $poidsgrade = null)
    {
        $data = array(        );
                if ($labelgrade != null) {
        	$data['labelgrade'] = $labelgrade;
        }
                if ($descgrade != null) {
        	$data['descgrade'] = $descgrade;
        }
                if ($abrevgrade != null) {
        	$data['abrevgrade'] = $abrevgrade;
        }
                if ($poidsgrade != null) {
        	$data['poidsgrade'] = $poidsgrade;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateGrades($idgrades, $labelgrade, $descgrade, $abrevgrade, $poidsgrade)

		 
    {
        $data = array(
        	            'labelgrade' => $grades->labelgrade,
                        'descgrade' => $grades->descgrade,
                        'abrevgrade' => $grades->abrevgrade,
                        'poidsgrade' => $grades->poidsgrade,
                            );
				
		 			$this->update($data, array(idgrades => $id));
			
				
				
        
    }
			 
		public function deleteGrades($id)
	   
    {
					$this->delete(array('idgrades' => $id));
			
				
        
    }

}
