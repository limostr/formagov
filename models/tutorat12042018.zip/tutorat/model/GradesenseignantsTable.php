<?php
 
//		$id=$row->idgradesenseignants;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class GradesenseignantsTable extends AbstractTableGateway
{
    protected $table ='gradesenseignants';
    protected $tableName ='gradesenseignants';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Gradesenseignants);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('gradesenseignants')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idgradesenseignants;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idgradesenseignants' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getGradesenseignants($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idgradesenseignants' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchGradesenseignants($idpersonnes, $idgrades, $dateobtentiongrade, $susponsiongrade, $causesusponsiongrade, $labelpersonaliser, $descgradeens, $titregradear)
    {
        $select = $this->getSelect();
                if ($idpersonnes != null) {
        	$select->where->like('idpersonnes' ,'%'.$idpersonnes.'%');
        }
                if ($idgrades != null) {
        	$select->where->like('idgrades' ,'%'.$idgrades.'%');
        }
                if ($dateobtentiongrade != null) {
        	$select->where->like('dateobtentiongrade' ,'%'.$dateobtentiongrade.'%');
        }
                if ($susponsiongrade != null) {
        	$select->where->like('susponsiongrade' ,'%'.$susponsiongrade.'%');
        }
                if ($causesusponsiongrade != null) {
        	$select->where->like('causesusponsiongrade' ,'%'.$causesusponsiongrade.'%');
        }
                if ($labelpersonaliser != null) {
        	$select->where->like('labelpersonaliser' ,'%'.$labelpersonaliser.'%');
        }
                if ($descgradeens != null) {
        	$select->where->like('descgradeens' ,'%'.$descgradeens.'%');
        }
                if ($titregradear != null) {
        	$select->where->like('titregradear' ,'%'.$titregradear.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveGradesenseignants(Gradesenseignants $gradesenseignants)
    {
        $data = array(
        	            'idpersonnes' => $gradesenseignants->idpersonnes,
                        'idgrades' => $gradesenseignants->idgrades,
                        'dateobtentiongrade' => $gradesenseignants->dateobtentiongrade,
                        'susponsiongrade' => $gradesenseignants->susponsiongrade,
                        'causesusponsiongrade' => $gradesenseignants->causesusponsiongrade,
                        'labelpersonaliser' => $gradesenseignants->labelpersonaliser,
                        'descgradeens' => $gradesenseignants->descgradeens,
                        'titregradear' => $gradesenseignants->titregradear,
                    );

        $id = (int)$gradesenseignants->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getGradesenseignants($id)) {
                $this->update($data, array('idgradesenseignants' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addGradesenseignants($idpersonnes, $idgrades, $dateobtentiongrade = null, $susponsiongrade = null, $causesusponsiongrade = null, $labelpersonaliser = null, $descgradeens = null, $titregradear = null)
    {
        $data = array(            'idpersonnes' => $idpersonnes,
                        'idgrades' => $idgrades,
                    );
                if ($dateobtentiongrade != null) {
        	$data['dateobtentiongrade'] = $dateobtentiongrade;
        }
                if ($susponsiongrade != null) {
        	$data['susponsiongrade'] = $susponsiongrade;
        }
                if ($causesusponsiongrade != null) {
        	$data['causesusponsiongrade'] = $causesusponsiongrade;
        }
                if ($labelpersonaliser != null) {
        	$data['labelpersonaliser'] = $labelpersonaliser;
        }
                if ($descgradeens != null) {
        	$data['descgradeens'] = $descgradeens;
        }
                if ($titregradear != null) {
        	$data['titregradear'] = $titregradear;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateGradesenseignants($idgradesenseignants, $idpersonnes, $idgrades, $dateobtentiongrade, $susponsiongrade, $causesusponsiongrade, $labelpersonaliser, $descgradeens, $titregradear)

		 
    {
        $data = array(
        	            'idpersonnes' => $gradesenseignants->idpersonnes,
                        'idgrades' => $gradesenseignants->idgrades,
                        'dateobtentiongrade' => $gradesenseignants->dateobtentiongrade,
                        'susponsiongrade' => $gradesenseignants->susponsiongrade,
                        'causesusponsiongrade' => $gradesenseignants->causesusponsiongrade,
                        'labelpersonaliser' => $gradesenseignants->labelpersonaliser,
                        'descgradeens' => $gradesenseignants->descgradeens,
                        'titregradear' => $gradesenseignants->titregradear,
                            );
				
		 			$this->update($data, array(idgradesenseignants => $id));
			
				
				
        
    }
			 
		public function deleteGradesenseignants($id)
	   
    {
					$this->delete(array('idgradesenseignants' => $id));
			
				
        
    }

}
