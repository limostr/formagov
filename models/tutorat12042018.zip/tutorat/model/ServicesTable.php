<?php
 
//		$id=$row->idservices;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ServicesTable extends AbstractTableGateway
{
    protected $table ='services';
    protected $tableName ='services';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Services);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('services')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idservices;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idservices' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getServices($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idservices' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchServices($idtypeservices, $idmenus, $idsousservices, $label, $description, $url, $afficher, $labelaffiche)
    {
        $select = $this->getSelect();
                if ($idtypeservices != null) {
        	$select->where->like('idtypeservices' ,'%'.$idtypeservices.'%');
        }
                if ($idmenus != null) {
        	$select->where->like('idmenus' ,'%'.$idmenus.'%');
        }
                if ($idsousservices != null) {
        	$select->where->like('idsousservices' ,'%'.$idsousservices.'%');
        }
                if ($label != null) {
        	$select->where->like('label' ,'%'.$label.'%');
        }
                if ($description != null) {
        	$select->where->like('description' ,'%'.$description.'%');
        }
                if ($url != null) {
        	$select->where->like('url' ,'%'.$url.'%');
        }
                if ($afficher != null) {
        	$select->where->like('afficher' ,'%'.$afficher.'%');
        }
                if ($labelaffiche != null) {
        	$select->where->like('labelaffiche' ,'%'.$labelaffiche.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveServices(Services $services)
    {
        $data = array(
        	            'idtypeservices' => $services->idtypeservices,
                        'idmenus' => $services->idmenus,
                        'idsousservices' => $services->idsousservices,
                        'label' => $services->label,
                        'description' => $services->description,
                        'url' => $services->url,
                        'afficher' => $services->afficher,
                        'labelaffiche' => $services->labelaffiche,
                    );

        $id = (int)$services->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getServices($id)) {
                $this->update($data, array('idservices' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addServices($idtypeservices, $labelaffiche, $idmenus = null, $idsousservices = null, $label = null, $description = null, $url = null, $afficher = null)
    {
        $data = array(            'idtypeservices' => $idtypeservices,
                        'labelaffiche' => $labelaffiche,
                    );
                if ($idmenus != null) {
        	$data['idmenus'] = $idmenus;
        }
                if ($idsousservices != null) {
        	$data['idsousservices'] = $idsousservices;
        }
                if ($label != null) {
        	$data['label'] = $label;
        }
                if ($description != null) {
        	$data['description'] = $description;
        }
                if ($url != null) {
        	$data['url'] = $url;
        }
                if ($afficher != null) {
        	$data['afficher'] = $afficher;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateServices($idservices, $idtypeservices, $idmenus, $idsousservices, $label, $description, $url, $afficher, $labelaffiche)

		 
    {
        $data = array(
        	            'idtypeservices' => $services->idtypeservices,
                        'idmenus' => $services->idmenus,
                        'idsousservices' => $services->idsousservices,
                        'label' => $services->label,
                        'description' => $services->description,
                        'url' => $services->url,
                        'afficher' => $services->afficher,
                        'labelaffiche' => $services->labelaffiche,
                            );
				
		 			$this->update($data, array(idservices => $id));
			
				
				
        
    }
			 
		public function deleteServices($id)
	   
    {
					$this->delete(array('idservices' => $id));
			
				
        
    }

}
