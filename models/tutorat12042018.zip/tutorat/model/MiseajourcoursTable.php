<?php
 
//		$id=$row->idmiseajourcours;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class MiseajourcoursTable extends AbstractTableGateway
{
    protected $table ='miseajourcours';
    protected $tableName ='miseajourcours';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Miseajourcours);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('miseajourcours')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idmiseajourcours;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idmiseajourcours' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getMiseajourcours($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idmiseajourcours' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchMiseajourcours($datemiseajours, $conceptions_idconceptions)
    {
        $select = $this->getSelect();
                if ($datemiseajours != null) {
        	$select->where->like('datemiseajours' ,'%'.$datemiseajours.'%');
        }
                if ($conceptions_idconceptions != null) {
        	$select->where->like('conceptions_idconceptions' ,'%'.$conceptions_idconceptions.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveMiseajourcours(Miseajourcours $miseajourcours)
    {
        $data = array(
        	            'datemiseajours' => $miseajourcours->datemiseajours,
                        'conceptions_idconceptions' => $miseajourcours->conceptions_idconceptions,
                    );

        $id = (int)$miseajourcours->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getMiseajourcours($id)) {
                $this->update($data, array('idmiseajourcours' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addMiseajourcours($conceptions_idconceptions, $datemiseajours = null)
    {
        $data = array(            'conceptions_idconceptions' => $conceptions_idconceptions,
                    );
                if ($datemiseajours != null) {
        	$data['datemiseajours'] = $datemiseajours;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateMiseajourcours($idmiseajourcours, $datemiseajours, $conceptions_idconceptions)

		 
    {
        $data = array(
        	            'datemiseajours' => $miseajourcours->datemiseajours,
                        'conceptions_idconceptions' => $miseajourcours->conceptions_idconceptions,
                            );
				
		 			$this->update($data, array(idmiseajourcours => $id));
			
				
				
        
    }
			 
		public function deleteMiseajourcours($id)
	   
    {
					$this->delete(array('idmiseajourcours' => $id));
			
				
        
    }

}
