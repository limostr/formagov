<?php
	//	$id['idpersonnes']=$row->idpersonnes;
	//	$id['idroles']=$row->idroles;
	//	$id['idanneeuniv']=$row->idanneeuniv;
		
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class RolespersonnesTable extends AbstractTableGateway
{
    protected $table ='rolespersonnes';
    protected $tableName ='rolespersonnes';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Rolespersonnes);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('rolespersonnes')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
											$id['idpersonnes']=$row->idpersonnes;
								$id['idroles']=$row->idroles;
								$id['idanneeuniv']=$row->idanneeuniv;
								
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
										'idpersonnes'=> null,
								'idroles'=> null,
								'idanneeuniv'=> null,
				 
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getRolespersonnes($idpersonnes,$idroles,$idanneeuniv)
	    {
        
					$rowset = $this->select(array('idpersonnes'=>$idpersonnes,'idroles'=>$idroles,'idanneeuniv'=>$idanneeuniv)); 
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $idpersonnes,$idroles,$idanneeuniv");
        }
        return $row;
    }
    
     public function matchRolespersonnes($idpersonnes, $idroles, $idanneeuniv)
    {
        $select = $this->getSelect();
                if ($idpersonnes != null) {
        	$select->where->like('idpersonnes' ,'%'.$idpersonnes.'%');
        }
                if ($idroles != null) {
        	$select->where->like('idroles' ,'%'.$idroles.'%');
        }
                if ($idanneeuniv != null) {
        	$select->where->like('idanneeuniv' ,'%'.$idanneeuniv.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveRolespersonnes(Rolespersonnes $rolespersonnes)
    {
        $data = array(
        	            'idpersonnes' => $rolespersonnes->idpersonnes,
                        'idroles' => $rolespersonnes->idroles,
                        'idanneeuniv' => $rolespersonnes->idanneeuniv,
                    );

        $id = (int)$rolespersonnes->id;
        if ($id == 0) {
            $this->insert($data);
        } else {

				if ($this->getRolespersonnes($rolespersonnes->idpersonnes,$rolespersonnes->idroles,$rolespersonnes->idanneeuniv)) {
                $this->update($data, array('idpersonnes'=>$rolespersonnes->idpersonnes,'idroles'=>$rolespersonnes->idroles,'idanneeuniv'=>$rolespersonnes->idanneeuniv));
            } else {
                throw new \Exception('Form id does not exit');
            }


        }
    }

    public function addRolespersonnes($idpersonnes, $idroles, $idanneeuniv)
    {
        $data = array(            'idpersonnes' => $idpersonnes,
                        'idroles' => $idroles,
                        'idanneeuniv' => $idanneeuniv,
                    );
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    

}
