<?php
 
//		$id=$row->idprojethabilitation;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ProjethabilitationTable extends AbstractTableGateway
{
    protected $table ='projethabilitation';
    protected $tableName ='projethabilitation';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Projethabilitation);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('projethabilitation')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idprojethabilitation;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idprojethabilitation' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getProjethabilitation($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idprojethabilitation' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchProjethabilitation($datecreation, $dateapplication, $idanneeuniv, $titreprojet, $descprojet, $versionprojet)
    {
        $select = $this->getSelect();
                if ($datecreation != null) {
        	$select->where->like('datecreation' ,'%'.$datecreation.'%');
        }
                if ($dateapplication != null) {
        	$select->where->like('dateapplication' ,'%'.$dateapplication.'%');
        }
                if ($idanneeuniv != null) {
        	$select->where->like('idanneeuniv' ,'%'.$idanneeuniv.'%');
        }
                if ($titreprojet != null) {
        	$select->where->like('titreprojet' ,'%'.$titreprojet.'%');
        }
                if ($descprojet != null) {
        	$select->where->like('descprojet' ,'%'.$descprojet.'%');
        }
                if ($versionprojet != null) {
        	$select->where->like('versionprojet' ,'%'.$versionprojet.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveProjethabilitation(Projethabilitation $projethabilitation)
    {
        $data = array(
        	            'datecreation' => $projethabilitation->datecreation,
                        'dateapplication' => $projethabilitation->dateapplication,
                        'idanneeuniv' => $projethabilitation->idanneeuniv,
                        'titreprojet' => $projethabilitation->titreprojet,
                        'descprojet' => $projethabilitation->descprojet,
                        'versionprojet' => $projethabilitation->versionprojet,
                    );

        $id = (int)$projethabilitation->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getProjethabilitation($id)) {
                $this->update($data, array('idprojethabilitation' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addProjethabilitation($idanneeuniv, $datecreation = null, $dateapplication = null, $titreprojet = null, $descprojet = null, $versionprojet = null)
    {
        $data = array(            'idanneeuniv' => $idanneeuniv,
                    );
                if ($datecreation != null) {
        	$data['datecreation'] = $datecreation;
        }
                if ($dateapplication != null) {
        	$data['dateapplication'] = $dateapplication;
        }
                if ($titreprojet != null) {
        	$data['titreprojet'] = $titreprojet;
        }
                if ($descprojet != null) {
        	$data['descprojet'] = $descprojet;
        }
                if ($versionprojet != null) {
        	$data['versionprojet'] = $versionprojet;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateProjethabilitation($idprojethabilitation, $datecreation, $dateapplication, $idanneeuniv, $titreprojet, $descprojet, $versionprojet)

		 
    {
        $data = array(
        	            'datecreation' => $projethabilitation->datecreation,
                        'dateapplication' => $projethabilitation->dateapplication,
                        'idanneeuniv' => $projethabilitation->idanneeuniv,
                        'titreprojet' => $projethabilitation->titreprojet,
                        'descprojet' => $projethabilitation->descprojet,
                        'versionprojet' => $projethabilitation->versionprojet,
                            );
				
		 			$this->update($data, array(idprojethabilitation => $id));
			
				
				
        
    }
			 
		public function deleteProjethabilitation($id)
	   
    {
					$this->delete(array('idprojethabilitation' => $id));
			
				
        
    }

}
