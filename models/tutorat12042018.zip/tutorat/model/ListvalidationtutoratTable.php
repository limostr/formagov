<?php
 
//		$id=$row->idlistvalidationtutorat;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class ListvalidationtutoratTable extends AbstractTableGateway
{
    protected $table ='listvalidationtutorat';
    protected $tableName ='listvalidationtutorat';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Listvalidationtutorat);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('listvalidationtutorat')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idlistvalidationtutorat;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idlistvalidationtutorat' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getListvalidationtutorat($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idlistvalidationtutorat' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchListvalidationtutorat($labelformation, $desclistevalidtutorat)
    {
        $select = $this->getSelect();
                if ($labelformation != null) {
        	$select->where->like('labelformation' ,'%'.$labelformation.'%');
        }
                if ($desclistevalidtutorat != null) {
        	$select->where->like('desclistevalidtutorat' ,'%'.$desclistevalidtutorat.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveListvalidationtutorat(Listvalidationtutorat $listvalidationtutorat)
    {
        $data = array(
        	            'labelformation' => $listvalidationtutorat->labelformation,
                        'desclistevalidtutorat' => $listvalidationtutorat->desclistevalidtutorat,
                    );

        $id = (int)$listvalidationtutorat->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getListvalidationtutorat($id)) {
                $this->update($data, array('idlistvalidationtutorat' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addListvalidationtutorat($labelformation = null, $desclistevalidtutorat = null)
    {
        $data = array(        );
                if ($labelformation != null) {
        	$data['labelformation'] = $labelformation;
        }
                if ($desclistevalidtutorat != null) {
        	$data['desclistevalidtutorat'] = $desclistevalidtutorat;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateListvalidationtutorat($idlistvalidationtutorat, $labelformation, $desclistevalidtutorat)

		 
    {
        $data = array(
        	            'labelformation' => $listvalidationtutorat->labelformation,
                        'desclistevalidtutorat' => $listvalidationtutorat->desclistevalidtutorat,
                            );
				
		 			$this->update($data, array(idlistvalidationtutorat => $id));
			
				
				
        
    }
			 
		public function deleteListvalidationtutorat($id)
	   
    {
					$this->delete(array('idlistvalidationtutorat' => $id));
			
				
        
    }

}
