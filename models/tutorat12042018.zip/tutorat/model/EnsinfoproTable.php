<?php
 
//		$id=$row->idensinfopro;
 


namespace Models\Tutorat\Model;

use Zend\Db\TableGateway\AbstractTableGateway,
    Zend\Db\Adapter\Adapter,
    Zend\Db\ResultSet\ResultSet,
    Zend\Db\Sql\Select;

class EnsinfoproTable extends AbstractTableGateway
{
    protected $table ='ensinfopro';
    protected $tableName ='ensinfopro';

    public function qi($name)  { return $this->adapter->platform->quoteIdentifier($name); }
    
    public function fp($name) { return $this->adapter->driver->formatParameterName($name); }

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet(new Ensinfopro);

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
    
   	public function newSelect() {
    	return new Select;
    }
    
    public function getSelect(&$select,$columnsArray=array()) 
    {
    	$select = new Select;
    	return $select->from('ensinfopro')->columns($columnsArray);    	
    }
    
    public function createIfNotExist($checkColumnsArray,$optionalColumns=array(),&$isRowCreated=null) {
			$rowset=$this->select($checkColumnsArray);
    		$row = $rowset->current();
    		$id=null;
    		if ($row == null) {
    			$allColumns=array_merge($checkColumnsArray,$optionalColumns);
    			$affectedRows = $this->insert($allColumns);
    			if ($affectedRows != 1) {
    				throw new \Exception("error: could not add line to db");
    			}
    			$id=$this->lastInsertValue;
    			$isRowCreated=true;
    		} else {
							$id=$row->idensinfopro;
			    			
    			$isRowCreated=false;
    		}
    		return $id;
    }
    
    //http://stackoverflow.com/questions/6156942/how-do-i-insert-an-empty-row-but-have-the-autonumber-update-correctly
    
    public function createEmptyRow() {
    	$row=array(
						'idensinfopro' => null
			    	
    	);
    	$affectedRows=$this->insert($row);
 		if ($affectedRows != 1) {
    		throw new \Exception("error: could not add empty row to db");
    	}
    	$id=$this->lastInsertValue;
    	return $id;
	}
    
			public function getEnsinfopro($id)
	    {
        
						$id  = (int) $id;
				$rowset = $this->select(array('idensinfopro' => $id));
				
       
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
     public function matchEnsinfopro($idpersonnes, $matricule, $typematricule, $poste, $fonction, $societer, $daterecrutement, $datefin, $descposte, $adresspro, $codepostal, $ville, $pays, $telephonepro, $autroinfoproens, $societerar, $postear, $fonctionar, $gradedeposte, $gradedepostear, $profisionofficiel)
    {
        $select = $this->getSelect();
                if ($idpersonnes != null) {
        	$select->where->like('idpersonnes' ,'%'.$idpersonnes.'%');
        }
                if ($matricule != null) {
        	$select->where->like('matricule' ,'%'.$matricule.'%');
        }
                if ($typematricule != null) {
        	$select->where->like('typematricule' ,'%'.$typematricule.'%');
        }
                if ($poste != null) {
        	$select->where->like('poste' ,'%'.$poste.'%');
        }
                if ($fonction != null) {
        	$select->where->like('fonction' ,'%'.$fonction.'%');
        }
                if ($societer != null) {
        	$select->where->like('societer' ,'%'.$societer.'%');
        }
                if ($daterecrutement != null) {
        	$select->where->like('daterecrutement' ,'%'.$daterecrutement.'%');
        }
                if ($datefin != null) {
        	$select->where->like('datefin' ,'%'.$datefin.'%');
        }
                if ($descposte != null) {
        	$select->where->like('descposte' ,'%'.$descposte.'%');
        }
                if ($adresspro != null) {
        	$select->where->like('adresspro' ,'%'.$adresspro.'%');
        }
                if ($codepostal != null) {
        	$select->where->like('codepostal' ,'%'.$codepostal.'%');
        }
                if ($ville != null) {
        	$select->where->like('ville' ,'%'.$ville.'%');
        }
                if ($pays != null) {
        	$select->where->like('pays' ,'%'.$pays.'%');
        }
                if ($telephonepro != null) {
        	$select->where->like('telephonepro' ,'%'.$telephonepro.'%');
        }
                if ($autroinfoproens != null) {
        	$select->where->like('autroinfoproens' ,'%'.$autroinfoproens.'%');
        }
                if ($societerar != null) {
        	$select->where->like('societerar' ,'%'.$societerar.'%');
        }
                if ($postear != null) {
        	$select->where->like('postear' ,'%'.$postear.'%');
        }
                if ($fonctionar != null) {
        	$select->where->like('fonctionar' ,'%'.$fonctionar.'%');
        }
                if ($gradedeposte != null) {
        	$select->where->like('gradedeposte' ,'%'.$gradedeposte.'%');
        }
                if ($gradedepostear != null) {
        	$select->where->like('gradedepostear' ,'%'.$gradedepostear.'%');
        }
                if ($profisionofficiel != null) {
        	$select->where->like('profisionofficiel' ,'%'.$profisionofficiel.'%');
        }
                $statement = $this->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $ret = $result->current();
        if ($ret !== false) {
        	$ret = array($ret);
            while (($line=$result->next()) !== false ) {
        		$ret[]=$line;
        	}
        }
        return $ret;
    }
    

    public function saveEnsinfopro(Ensinfopro $ensinfopro)
    {
        $data = array(
        	            'idpersonnes' => $ensinfopro->idpersonnes,
                        'matricule' => $ensinfopro->matricule,
                        'typematricule' => $ensinfopro->typematricule,
                        'poste' => $ensinfopro->poste,
                        'fonction' => $ensinfopro->fonction,
                        'societer' => $ensinfopro->societer,
                        'daterecrutement' => $ensinfopro->daterecrutement,
                        'datefin' => $ensinfopro->datefin,
                        'descposte' => $ensinfopro->descposte,
                        'adresspro' => $ensinfopro->adresspro,
                        'codepostal' => $ensinfopro->codepostal,
                        'ville' => $ensinfopro->ville,
                        'pays' => $ensinfopro->pays,
                        'telephonepro' => $ensinfopro->telephonepro,
                        'autroinfoproens' => $ensinfopro->autroinfoproens,
                        'societerar' => $ensinfopro->societerar,
                        'postear' => $ensinfopro->postear,
                        'fonctionar' => $ensinfopro->fonctionar,
                        'gradedeposte' => $ensinfopro->gradedeposte,
                        'gradedepostear' => $ensinfopro->gradedepostear,
                        'profisionofficiel' => $ensinfopro->profisionofficiel,
                    );

        $id = (int)$ensinfopro->id;
        if ($id == 0) {
            $this->insert($data);
        } else {
		
					if ($this->getEnsinfopro($id)) {
                $this->update($data, array('idensinfopro' => $id));
            } else {
                throw new \Exception('Form id does not exit');
            }
				
            
        }
    }

    public function addEnsinfopro($idpersonnes, $matricule = null, $typematricule = null, $poste = null, $fonction = null, $societer = null, $daterecrutement = null, $datefin = null, $descposte = null, $adresspro = null, $codepostal = null, $ville = null, $pays = null, $telephonepro = null, $autroinfoproens = null, $societerar = null, $postear = null, $fonctionar = null, $gradedeposte = null, $gradedepostear = null, $profisionofficiel = null)
    {
        $data = array(            'idpersonnes' => $idpersonnes,
                    );
                if ($matricule != null) {
        	$data['matricule'] = $matricule;
        }
                if ($typematricule != null) {
        	$data['typematricule'] = $typematricule;
        }
                if ($poste != null) {
        	$data['poste'] = $poste;
        }
                if ($fonction != null) {
        	$data['fonction'] = $fonction;
        }
                if ($societer != null) {
        	$data['societer'] = $societer;
        }
                if ($daterecrutement != null) {
        	$data['daterecrutement'] = $daterecrutement;
        }
                if ($datefin != null) {
        	$data['datefin'] = $datefin;
        }
                if ($descposte != null) {
        	$data['descposte'] = $descposte;
        }
                if ($adresspro != null) {
        	$data['adresspro'] = $adresspro;
        }
                if ($codepostal != null) {
        	$data['codepostal'] = $codepostal;
        }
                if ($ville != null) {
        	$data['ville'] = $ville;
        }
                if ($pays != null) {
        	$data['pays'] = $pays;
        }
                if ($telephonepro != null) {
        	$data['telephonepro'] = $telephonepro;
        }
                if ($autroinfoproens != null) {
        	$data['autroinfoproens'] = $autroinfoproens;
        }
                if ($societerar != null) {
        	$data['societerar'] = $societerar;
        }
                if ($postear != null) {
        	$data['postear'] = $postear;
        }
                if ($fonctionar != null) {
        	$data['fonctionar'] = $fonctionar;
        }
                if ($gradedeposte != null) {
        	$data['gradedeposte'] = $gradedeposte;
        }
                if ($gradedepostear != null) {
        	$data['gradedepostear'] = $gradedepostear;
        }
                if ($profisionofficiel != null) {
        	$data['profisionofficiel'] = $profisionofficiel;
        }
                $affectedRows=$this->insert($data);
                return $affectedRows;
            }
    
   		 
		    public function updateEnsinfopro($idensinfopro, $idpersonnes, $matricule, $typematricule, $poste, $fonction, $societer, $daterecrutement, $datefin, $descposte, $adresspro, $codepostal, $ville, $pays, $telephonepro, $autroinfoproens, $societerar, $postear, $fonctionar, $gradedeposte, $gradedepostear, $profisionofficiel)

		 
    {
        $data = array(
        	            'idpersonnes' => $ensinfopro->idpersonnes,
                        'matricule' => $ensinfopro->matricule,
                        'typematricule' => $ensinfopro->typematricule,
                        'poste' => $ensinfopro->poste,
                        'fonction' => $ensinfopro->fonction,
                        'societer' => $ensinfopro->societer,
                        'daterecrutement' => $ensinfopro->daterecrutement,
                        'datefin' => $ensinfopro->datefin,
                        'descposte' => $ensinfopro->descposte,
                        'adresspro' => $ensinfopro->adresspro,
                        'codepostal' => $ensinfopro->codepostal,
                        'ville' => $ensinfopro->ville,
                        'pays' => $ensinfopro->pays,
                        'telephonepro' => $ensinfopro->telephonepro,
                        'autroinfoproens' => $ensinfopro->autroinfoproens,
                        'societerar' => $ensinfopro->societerar,
                        'postear' => $ensinfopro->postear,
                        'fonctionar' => $ensinfopro->fonctionar,
                        'gradedeposte' => $ensinfopro->gradedeposte,
                        'gradedepostear' => $ensinfopro->gradedepostear,
                        'profisionofficiel' => $ensinfopro->profisionofficiel,
                            );
				
		 			$this->update($data, array(idensinfopro => $id));
			
				
				
        
    }
			 
		public function deleteEnsinfopro($id)
	   
    {
					$this->delete(array('idensinfopro' => $id));
			
				
        
    }

}
